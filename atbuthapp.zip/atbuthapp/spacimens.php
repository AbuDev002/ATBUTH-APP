<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Add New User";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
<div class="container">
	<?php include_once('incs/upnavbar.php');?>
	<div class="row" style="background: #f5f5f5;">
		<?php include_once('incs/sidemenu.php');?>
		<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
			<?php
			include_once('connection.php');
			if(isset($_POST['btnAddSpacimen'])){
				$spacimen_name = $_POST['spacimen_name'];
				
				$spacimen_name = mysqli_real_escape_string($conms,$spacimen_name);
				
				if(empty($spacimen_name)){
					echo "<p class='alert alert-danger'>Please enter spacimen name!</p>";
				}else{
					include_once('connection.php');
					$addspacimen_qry = mysqli_query($conms,"INSERT INTO tbl_spacimens (spacimen_name)  VALUES('".$spacimen_name."')");
					if($addspacimen_qry){
						echo "<p class='alert alert-success'>Spacimen Added Successfully!</p>";
					}else{
						echo "<p class='alert alert-danger'>Unable to add spacimen</p>";
					}
				}
			}
			?>
			<form action="" method="post">
				<div class="card">
					<div class="card-header"><span class="fa fa-plus"></span> Spacimen Details</div>
					<div class="card-body">
						<div class="row">
							<div class="col-md-6">
								<fieldset class="scheduler-border">
									<legend class="scheduler-border"><strong>Add New Spacimen</strong></legend>
									<div class="form-group">
										<input type="text" name="spacimen_name" class="form-control" autocomplete="off" value="<?php echo isset($_POST['spacimen_name']) ? $_POST['spacimen_name'] : '' ?>" placeholder="Enter spacimen name...">
									</div>
									<div class="form-group">
										<button type="submit" name="btnAddSpacimen" class="btn btn-primary">Add Spacimen</button>
									</div>

								</fieldset>
							</div>
							<div class="col-md-6">
								<fieldset class="scheduler-border">
									<legend class="scheduler-border"><strong>List of Spacimens</strong></legend>
									<div class="message-show"></div>
									<table class="table table-bordered table-responsive table-striped table-hover custom_table" style="width:100%;">
					 	<thead>
						 	<tr>
						 		<th>S/N</th>
						 		<th>Name of Spacimen</th>
						 		<th></th>
						 		<th></th>
						 	</tr>
					 	</thead>
					 	<tbody>
					 	<?php 
					 		$count = 0;
					 		
					 			include_once('connection.php');
					 			$getspacimen_sql = mysqli_query($conms,"select * from tbl_spacimens");
					 			while($rows_rs = mysqli_fetch_array($getspacimen_sql)){
					 			$count++;
					 			
							 	?>
							 	<tr>
							 		 <td style="display: none;" class="spacimen_id"><?php echo $rows_rs['id'];?></td>
							 		<td><?php echo $count;?></td>
							 		<td><?php echo $rows_rs['spacimen_name'];?></td>
									<?php if($_SESSION['account_type'] == 'Superadmin'){?>
							 		<td><a onclick="return confirm('Are you sure to delete');" href="deletespacimen.php?deletespacimen=<?php echo $rows_rs['id'];?>" title="Delete"><i class="fa fa-trash"></i></a></td>
							 		<td><a href="#" title="Edit" class="SpacimenEdit_btn"><i class="fa fa-edit"></i></a></td>
									<?php }?>
								</tr>
							<?php } ?>
					 </tbody>
					 </table>
								</fieldset>
							</div>
						</div>

					</div>
				</div>

			</form>
		</div>
	</div>
	<?php include_once('modals/spacimens/editspacimen.php');?>
	<?php include_once('incs/footer.php');?>
	<script>
    //update spacimen
        $('#UpdateSpacimen').click(function(e){
            e.preventDefault();
            var spacimen_id = $('#spacimenid_edit').val();
            var spacimen_name = $('.spacimen_name').val();
            $.ajax({
                url:'app/spacimens/UpdateChanges.php',
                type:'POST',
                data:{
                    'checking_update':true,
                    'spacimen_id':spacimen_id,
                    'spacimen_name':spacimen_name
                },
                success: function(response){
                    $('#EditSpacimentModal').modal('hide');
                    $('.message-show').append('\<div class="alert alert-success alert-dismissible fade show" role="alert">\
                  <strong>Hey!</strong> '+response+'\
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\
                  </div>\
                  ');
                   
                }
            });

        });
    //fetch spacimen details for editing
          $(document).on("click",".SpacimenEdit_btn", function(){
            var spacimen_id = $(this).closest('tr').find('.spacimen_id').text();
            $.ajax({
                url:'app/spacimens/updateSpacimen.php',
                type:'POST',
                data:{
                    'checking_edit':true,
                    'spacimen_id':spacimen_id
                },
                success: function(response){
                    $.each(response, function(key, spacimenedit) {
                        $('#spacimenid_edit').val(spacimenedit['id']);
                        $('.spacimen_name').val(spacimenedit['spacimen_name']);
                       
                    });

                    $('#EditSpacimentModal').modal('show');
                }
            });
        });
</script>
