<?php
include_once('connection.php');
if(isset($_GET['deleteclinic'])) {
$deltid = $_GET['deleteclinic']; 
$usertDetails = mysqli_query($conms,"DELETE FROM tbl_clinics WHERE id=".$deltid."");
header('location:clinics.php');
}else{
    header('location:clinics.php');
}
?>