<?php
require_once('function.php');
connectdb();
session_start();

if(isset($_POST["email"]) or isset($_POST["password"])){

//$username = $_POST["username"];
$email = $_POST["email"];
$password = $_POST["password"];
$mdpass = md5($password);

$checkUser = mysqli_query($conms,"SELECT password,account_staus,account_type,user_id,name,lastupdated FROM userinfo WHERE email='".$email."'");
if($rows = mysqli_num_rows($checkUser) > 0){
$data = mysqli_fetch_array($checkUser);
if ($data['account_staus']==1) {
	echo "Your Account is Currently Blocked";
}else{
	//$data['password'] == $mdpass
//$return_arr["status"]=1;
//-------------------------------------------------->>>>>>>>>>>>>>>>>>>> Make Auth
$tm = time();
$si = "$email$tm";
$sid = md5($si);
$_SESSION['sid'] = $sid;
$_SESSION['account_type'] = $data['account_type'];
$_SESSION['userid'] = $data['user_id'];
$_SESSION['email'] = $email;
$_SESSION['name'] = $data['name'];
$time = date("H:i:s");
$date = date("Y-m-d");
//$_SESSION['username'] = $email;
mysqli_query($conms,"UPDATE userinfo SET sid='".$sid."' WHERE email='".$email."'");
$last_login =mysqli_query($conms,"UPDATE userinfo SET lastlogin=now() WHERE email ='".$email."'");
$login_session =mysqli_query($conms,"INSERT INTO logging_history (logindate,email,name,time_in,time_out) values('".$date."','".$email."','".$_SESSION['name']."','".$time."','Not Available')");
//-------------------------------------------------->>>>>>>>>>>>>>>>>>>> Make Auth
if($data['account_type'] =="User"){
 	echo "User";
}elseif($data['account_type'] =="Superadmin"){
	echo "Superadmin";
}else{
	echo "User does not exist";
}  //end else
exit();
}

}else{
	echo "Inavlid Username or Password";
}
}
?>