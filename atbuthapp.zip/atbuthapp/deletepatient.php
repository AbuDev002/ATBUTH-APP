<?php
include_once('connection.php');
if(isset($_GET['deletepatient'])) {
$deltid = $_GET['deletepatient']; 
$usertDetails = mysqli_query($conms,"DELETE FROM patients WHERE id=".$deltid."");
header('location:patients.php');
}else{
    header('location:patients.php');
}
?>