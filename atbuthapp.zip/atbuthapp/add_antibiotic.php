<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Add New Antibiotic";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					<?php
					include_once('connection.php');
					if(isset($_POST['btnAddAntibiotic'])){
					$antibiotic_name = $_POST['antibiotic_name'];
					
					
					
					$antibiotic_name = mysqli_real_escape_string($conms,$antibiotic_name);
					
					
					if(empty($antibiotic_name)){
						echo "<p class='alert alert-danger'>Please enter antibiotic name!</p>";
					}else{
						include_once('connection.php');
						//$adduser_sql =;
						$adduser_qry = mysqli_query($conms,"INSERT INTO antibiotics (antibiotic_name)  VALUES('".$antibiotic_name."')");
						if($adduser_qry){
							echo "<p class='alert alert-success'>Added Successfully!</p>";
						}else{
							echo "<p class='alert alert-danger'>Unable to add antibiotic</p>";
						}
					}
				}
			?>
					<form action="" method="post">
						 <div class="card">
					 	<div class="card-header"><span class="fa fa-plus"></span> Add Antibiotic</div>
					 	<div class="card-body">
					 		<div class="form-group">
					 			<input type="text" name="antibiotic_name" class="form-control" autocomplete="off" placeholder="Antibiotic name...">
					 		</div>
							<!-- <div class="form-group">
							<input type="email" id="email" pattern=".+@fptb.edu.ng" size="30" required>
							</div> -->
					 		<div class="form-group">
					 			<button type="submit" class="btn btn-primary margin-bottom" name="btnAddAntibiotic"><i class="fa fa-plus"></i> Add Antibiotic</button>
					 		</div>
					
					 	</div>
					 </div>
						
					</form>
				</div>
			</div>
			
<?php include_once('incs/footer.php');?>