<?php
        //session_start();
    ob_start();
    //error_reporting(1);
    require_once 'vendor/autoload.php';
    if(isset($_GET['pid'])){
      $pid = (int) $_GET['pid'];
    }
    
?>
<?php include_once('connection.php');?>

<!Doctype html>
<html>
  <head>
    <title>Patient Report Form</title>

    <style type="text/css">
      #container{
        width:100%;
        height:auto;
        margin:0px auto;
        margin-top:20px;
        text-indent:5px;
        font-size:12px;
                               
      }
        
      th#mdb{
        background-image:url("images/sch-logo.png") no-repeat;
        background-size:contain;
      }
      
      #report_details td{
        border:1px solid black;
        border-collapse:collapse;
      }
      
      .head{
        background:#91C5D4;
        }
    @page { 
        margin-top: 180px;
        margin-left: 50px;
        margin-right: 50px;
        margin-bottom: 50px;
        background-color: skyblue;
       }
      #header { position: fixed; left: -45px; top: -180px; right: -45px; height: 100px; background-color: #f5f5f5; text-align: center; width:100%; }
      #footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 160px; background-color: #f5f5f5; }
      /*#footer .page:after { content: counter(page, upper-roman); }*/
      
      /*table#report_details{page-break-inside:avoid}*/
      .paragraph{
        text-align: justify;
        line-height: 30px;
      }

      .left_area{
        width:49%;
        float:left;
        display:block;
        min-height: 550px;
      }
      .right_area{
        width:50%;
        border-radius:10px;
        float:right;
        display:block;
        min-height: 550px;
        
      }
      .clear{
        clear:both;
        overflow: auto;
      }

      .uright{
        width:40%;
        /*border:1px solid black;*/
        height: 300px;
        float:right;
        font-size: 14px;
      }
      .uleft{
              width:60%;
              /*border:1px solid black;*/
              height: 400px;
              float:left;
              font-size: 14px;
            }

      .tbl_antibiotics{
        width:100%;
        border:1px solid black;
        border-spacing: -1px;
        /*margin-top:20px;*/
      }
      .tbl_antibiotics td{
        border:1px solid black;
        
      }

      .widal{
        width:90%;
        /*border:1px solid black;
        border-spacing: -1px;*/
        /*margin-top:20px;*/
      }

      ul.reportList{
        list-style-type: none;
        padding:0px;
        margin:0px;
      }
      ul.reportList li{
        line-height: 26px;
      }
     /* .widal td{
        border:1px solid black;
        
      }*/

      #isolates{
        width:100%;
        border-right:1px solid black;
        border-top:0px;
        border-bottom:0px;
        border-left:0px;
        border-right:0px;
        border-spacing: -1px;
        /*margin-top:20px;*/
      }
      #isolates td{
        border:1px solid black;
        
      }

     /* table#isolates td{
         border:1px solid black;
      }*/

      .box-tick{
        height: 25px;
        width:40px;
        border:1px solid black;
        margin:5px;
        margin-bottom: 0px;
        float-left;
      }
    </style>
  </head>
  
<body>
<div id="container">

<div id="header">
    <table align="center"  cellpadding="0"  width="100%" style="font-size:12px; border-collapse:collapse;">
      <tr>
        <td align="right" width="50"><img src="http://localhost/atbuthapp/images/abuthlogo.png" width="100" height="80" style="margin-top: 10px;"></td>
        <td align="center" colspan="2"><h1>ABUBAKAR TAFAWA BALEWA UNIVERSITY <br/> TEACHING HOSPITAL, BAUCHI</h1></td>
      </tr>
      <tr>
        
        <td colspan="3" align="center" valign="top" height="10"><h2 style="padding:0px; background:#29166F; color:#fff;">MICROBIOLOGY SEROLOGY REQUEST/REPORT FORM</h2></td>
        
      </tr>
      
    </table>
    
</div>
  <div id="footer">
    <hr/>
  </div>

<table class="profit_list" width="100%" border="1" id="report_details" cellspacing="0" style="margin-top:-50px;font-size:12px;border-left:0px;">
  <?php
    include_once('connection.php');
    $patientname_sql = mysqli_query($conms,"select * from patients where id=$pid");
    $patient_data = mysqli_fetch_array($patientname_sql);
  ?>
  <tr>
    <td style="height:30px;" valign="top">
      <strong>NAME:</strong>
      <p><?php echo strtoupper($patient_data['surname'].' '.$patient_data['firstname'].' '.$patient_data['othername']);?></p>
    </td>
    <td valign="top">
      <strong>AGE</strong>
      <p><?php echo strtoupper($patient_data['age']);?></p>
    </td>
  <td valign="top">
    <strong>SEX</strong>
    <p><?php echo strtoupper($patient_data['gender']);?></p>
  </td>
  <td valign="top">
    <strong>ADDRESS</strong>
    <p><?php echo strtoupper($patient_data['address']);?></p>
  </td>
  
  </tr>
  <tr>
  <td style="height:50px;" valign="top" rowspan="2">
    <strong>WARD/CLINIC:</strong>
    <p><?php echo strtoupper($patient_data['ward_clinic']);?></p>
  </td>
  <td valign="top" rowspan="2">
    <strong>HOSPITAL NO.</strong>
    <p><?php echo strtoupper($patient_data['hospital_no']);?></p>
  </td>
  <td valign="top" rowspan="2">
    <strong>BED NO.</strong>
    <p><?php echo strtoupper($patient_data['bedno']);?></p>
  </td>
  <td valign="top">
    <strong>LAB NO</strong>
    <p><?php echo strtoupper($patient_data['lab_no']);?></p>
  </td>
  </tr>
  <tr>
    <td></td>
  </tr>
  <tr>
    <td style="height:30px;" valign="top">
      <strong>CLINICAL DIAGNOSIS</strong>
      <p><?php echo strtoupper($patient_data['clinical_diagnosis']);?></p>
    </td>
     <td style="height:30px;" colspan="2" valign="top">
      <strong>CLINICAL/CONSULTANT NAME</strong>
      <p><?php echo strtoupper($patient_data['consultant']);?></p>
    </td>
     <td style="height:30px;" valign="top">
      <strong>SIGN:________________<br>DATE:_______________</strong>
      <p></p>
    </td>
  </tr>
  
</table>
<br/>
<center><h3 style="padding:0px;margin:0px;text-decoration: underline;font-size: 16px;">INVESTIGATION(S)</h3></center>

<!-- <P style="font-size:12px;text-align:right"> 2347</P> -->
<div class="container">
      <div class="left_area">
        <table class="request_type">
          <tr>
            <td width="50"><div class="box-tick"></div></td>
            <td>WIDAL TEST</td>
          </tr>
          <tr>
            <td><div class="box-tick"></div></td>
            <td>HBsAg</td>
          </tr>
          <tr>
            <td><div class="box-tick"></div></td>
            <td>HBsAb</td>
          </tr>
          <tr>
            <td><div class="box-tick"></div></td>
            <td>HCV</td>
          </tr>
          <tr>
            <td><div class="box-tick"></div></td>
            <td>RF</td>
          </tr>   
        </table>
      </div>

      <!-- begin right area -->
      <div class="right_area">
        <table class="request_type">
        <tr>
          <td width="50"><div class="box-tick"></div></td>
          <td>ASO TITRE</td>
        </tr>
        <tr>
          <td><div class="box-tick"></div></td>
          <td>RVS</td>
        </tr>
        <tr>
          <td><div class="box-tick"></div></td>
          <td>HBeAb</td>
        </tr>
        <tr>
          <td><div class="box-tick"></div></td>
          <td>HBeAg</td>
        </tr>
        <tr>
          <td><div class="box-tick"></div></td>
          <td>HBcAb</td>
        </tr>
        <tr>
          <td><div class="box-tick"></div></td>
          <td>VDRL</td>
        </tr>
      </table>
      </div>
      <div class="clear"></div> 
      <h4>Other (Specify)__________________________________________________________________________________________________</h4>
       <p>________________________________________________________________________________________________________________</p>
        <p>________________________________________________________________________________________________________________</p>

        <div class="uleft">
          <table class="widal" align="center">
            <tr>
              <th><h3>WIDAL</h3></th>
            </tr>
            <tr>
              <td><strong>S. TYPHI</strong></td>
              <td><strong>O:</strong></td>
              <td><strong>H:</strong></td>
            </tr>
            <tr>
              <td><strong>S. PARATYPHI</strong></td>
              <td><strong>AO:</strong></td>
              <td><strong>AH:</strong></td>
            </tr>
            <tr>
              <td><strong>S. PARATYPHI</strong></td>
              <td><strong>BO:</strong></td>
              <td><strong>BH:</strong></td>
            </tr>
            <tr>
              <td><strong>S. PARATYPHI</strong></td>
              <td><strong>CO:</strong></td>
              <td><strong>CH:</strong></td>
            </tr>
            <tr>
              <td colspan="4">
                <p style="font-weight: bold;">COMMENT:____________________________________________<p>
                <p>_______________________________________________________<p>
                <p>_______________________________________________________<p>
              </td>
            </tr>
            <tr>
              <td colspan="4">
                <p style="font-weight: bold;">NAME:________________________________________________<p>
              </td>
            </tr>
            <tr>
              <td colspan="4">
                <p style="font-weight: bold;">SIGN:_______________________DATE_____________________<p>
              </td>
            </tr>
            <tr>
              <td colspan="4">
                <p style="font-weight: bold;background: #000;color:#fff;"><i>MED. LAB. SCIENTIST</i></p>
              </td>
            </tr>
          </table>
        </div>
        <div class="uright">
          <h3 style="text-decoration: underline;">REPORT</h3>
           <ul class="reportList">
             <li><strong>HBsAg:_______________________________</strong></li>
             <li><strong>HCV:_________________________________</strong></li>
             <li><strong>RF:__________________________________</strong></li>
             <li><strong>ASO TITRE:___________________________</strong></li>
             <li><strong>HBeAb:_______________________________</strong></li>
             <li><strong>HBeAg:_______________________________</strong></li>
             <li><strong>RVS:_________________________________</strong></li>
             <li><strong>HBsAb:_________________________________</strong></li>
             <li><strong>HBcAb:_________________________________</strong></li>
           </ul>
           <br>
           <div style="width:100%;height:100px;border:1px solid #000;margin-top: 5px;">
            <strong><i>CONSULTANT COMMENT</i></strong>
          </div>
        </div>
        <div class="clear"></div>
</div>
</div>

</body>
</html>
<?php   
  $html = ob_get_clean();
  use Dompdf\Dompdf;
  use Dompdf\Options;
  require_once 'vendor/autoload.php';
  $options = new Options();
    $options->set('isRemoteEnabled', TRUE);
    $options->set('debugKeepTemp', TRUE);
    $options->set('isHtml5ParserEnabled', true);
  $dompdf = new DOMPDF($options);
  $contxt = stream_context_create([ 
    'ssl' => [ 
        'verify_peer' => FALSE, 
        'verify_peer_name' => FALSE,
        'allow_self_signed'=> TRUE
    ] 
]);
$dompdf->setHttpContext($contxt);
  $dompdf->set_paper("A4","Portrait");
  $dompdf->loadHtml($html);
  $dompdf->render();
  $dompdf->stream('seriology_report.pdf');
?>