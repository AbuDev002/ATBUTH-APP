<?php
        //session_start();
		ob_start();
		//error_reporting(1);
		require_once 'vendor/autoload.php';
		if(isset($_GET['pid'])){
			$pid = (int) $_GET['pid'];
		}
		
?>
<?php include_once('connection.php');?>

<!Doctype html>
<html>
	<head>
		<title>Patient Report Form</title>

		<style type="text/css">
			#container{
				width:100%;
				height:auto;
				margin:0px auto;
				margin-top:20px;
				text-indent:5px;
                               
			}
				
			th#mdb{
				background-image:url("images/sch-logo.png") no-repeat;
				background-size:contain;
			}
			
			#report_details td{
				border:1px solid black;
				border-collapse:collapse;
			}
			
			.head{
				background:#91C5D4;
				}
		@page { margin: 180px 50px;background-color: skyblue; }
			#header { position: fixed; left: -45px; top: -180px; right: -45px; height: 120px; background-color: #f5f5f5; text-align: center; width:100%; }
			#footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 160px; background-color: #f5f5f5; }
			#footer .page:after { content: counter(page, upper-roman); }
			
			/*table#report_details{page-break-inside:avoid}*/
		  .paragraph{
		  	text-align: justify;
		  	line-height: 30px;
		  }

		  .left_area{
			  width:50%;
			  /* height:500px; */
			  float:left;
			  display:block;
		  }
		  .right_area{
			  width:50%;
			  /* min-height:500px; */
			  border-left:1px solid black;
			  border-radius:10px;
			  float:right;
			  display:block;
		  }
		  .clear{
			  clear:both;
			  overflow: auto;
		  }
		  .tbl_antibiotics{
			  width:100%;
			  border:1px solid black;
			  border-spacing: -1px;
			  margin-top:20px;
		  }
		  .tbl_antibiotics td{
			  border:1px solid black;
			  
		  }

		  /*body {
			background-color: #c7b39b;
			}*/

		</style>
	</head>
	
<body>
<div id="container">

<div id="header">
		<table align="center"  cellpadding="0"  width="100%" style="font-size:12px; border-collapse:collapse;">
			<tr>
				<td align="right" width="50"><img src="http://localhost/abuthapp/images/abuthlogo.png" width="100" height="100" style="margin-top: 10px;"></td>
				<td align="center" colspan="2"><h1>ABUBAKAR TAFAWA BALEWA UNIVERSITY <br/> TEACHING HOSPITAL, BAUCHI</h1></td>
			</tr>
			<tr>
				
				<td colspan="3" align="center" valign="top" height="10"><h2 style="padding:0px; background:#29166F; color:#fff;">MEDICAL MICROBIOLOGY REPORT FORM</h2></td>
				
			</tr>
			
		</table>
		
</div>
	<div id="footer">
	<!-- <table width="100%" align="center">
		<tr>
			<td width="400"><b>MED. LAB SCIENTIST _______________________________</b></td>
		</tr>
	</table> -->
	<hr/>
	<p style="font-size:12px;"><b>NAME:</b>_______________________________________________</p>
	<p style="font-size:12px;"><b>SIGN:</b>______________________________DATE_____________________</p>
	<p style="font-size:12px;"><strong><i>MED. LAB SCIENTIST</i></strong></p>
	<br>
	<p style="text-align:right;"><?php echo date('F j, Y');?></p>
	</div>

<table class="profit_list" width="100%" border="1" id="report_details" cellspacing="0" style="margin-top:-50px;font-size:14px;border-left:0px;">
	<?php
		include_once('connection.php');
		$patientname_sql = mysqli_query($conms,"select * from patients where id=$pid");
		$patient_data = mysqli_fetch_array($patientname_sql);
	?>
  <tr>
    <td><strong>SURNAME:</strong></td>
    <td><?php echo strtoupper($patient_data['surname']);?></td>
    <td><strong>FIRST NAME:</strong></td>
    <td><?php echo strtoupper($patient_data['firstname']);?></td>
	<td><strong>OTHER NAME:</strong></td>
    <td><?php echo strtoupper($patient_data['othername']);?></td>
  </tr>
  <?php
		include_once('connection.php');
		$patientlabreport_sql = mysqli_query($conms,"select * from patients_lab_report where 	patient_id=$pid");
		$patientlabreport_data = mysqli_fetch_array($patientlabreport_sql);
	?>
  <tr>
    <td><strong>CLINICAL DIAGNOSIS:</strong></td>
    <td><?php echo strtoupper($patientlabreport_data['clinical_diagnosis']);?></td>
    <td><strong>SPACEMEN(S):</strong></td>
    <td><?php echo strtoupper($patientlabreport_data['spacemen']);?></td>
	<td><strong>INVESTIGATION REQUESTED:</strong></td>
    <td><?php echo strtoupper($patientlabreport_data['investigation_requested']);?></td>
  </tr>


</table>
<table style="width:100%;">
		  <tr>
		  	<td><strong>HOSPITAL NO:</strong> <?php echo strtoupper($patient_data['hospital_no']);?></td>
		  	<td><strong>LAB NO:</strong> <?php echo strtoupper($patient_data['lab_no']);?></td>
		  	<td><strong>SEX:</strong> <?php echo strtoupper($patient_data['gender']);?></td>
		  	<td><strong>AGE:</strong> <?php echo strtoupper($patient_data['age']);?></td>
		  	<td></td>
		  </tr>
</table>
<!-- <P style="font-size:12px;text-align:right"> 333080</P>
<P style="font-size:12px;text-align:right"> 2347</P> -->
<div class="container">
		  	<div class="left_area">
		  		<p><strong>MACROSCOPY:</strong></p>
				<br>
				<br>
				<br>
				<br>
				<p><strong>MICROSCOPY:</strong></p>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				
				<p><strong>CULTURE:</strong></p>
				<ol style="margin:0px;padding:0px;">
		  			<li>---------------------------------------------------</li>
		  			<li>---------------------------------------------------</li>
		  			<li>---------------------------------------------------</li>
				</ol>
				<br>
				<br>
				<br>
			
			 
			</div>
		  	<div class="right_area">
			 
		  		<table class="tbl_antibiotics">
				  	<thead>
						<tr>
							<td colspan="4" align="center" height="50">
								<i><strong>SENSITIVITY TEST</strong></i><br>
								<small>Organism(s)</small>
							</td>
						</tr>
						<tr>
						<td align="center"><strong>Antibiotic</strong></td>
						<td align="center"><strong>1</strong></td>
						<td align="center"><strong>2</strong></td>
						<td align="center"><strong>3</strong></td>
						</tr>
					</thead>
					<tbody>
					<?php
						include_once('connection.php');
						$sql_getantibiotics = mysqli_query($conms,"select * from patient_antibiotic_report where patient_id=$pid");
						while($list_antibiotics = mysqli_fetch_array($sql_getantibiotics)){
					?>
					<tr>
						<td>
						<?php 
							$getAntibiotic = mysqli_query($conms,"select * from antibiotics WHERE id =".$list_antibiotics['antibiotic_id']."");
							$antibioticName = mysqli_fetch_array($getAntibiotic);
							echo $antibioticName['antibiotic_name'];
						?>
						</td>
						<td><?php echo $list_antibiotics['test1'];?></td>
						<td></td>
						<td></td>
					</tr>
					<?php } ?>
					</tbody>
				</table>
				<p>S = Sensitive, R= Resistant, I = Intermediate</p>
			</div>
			<div class="clear"></div>
			
		  
</div>
</div>

</body>
</html>
<?php		
	$html = ob_get_clean();
	use Dompdf\Dompdf;
	use Dompdf\Options;
	require_once 'vendor/autoload.php';
	$options = new Options();
    $options->set('isRemoteEnabled', TRUE);
    $options->set('debugKeepTemp', TRUE);
    $options->set('isHtml5ParserEnabled', true);
	$dompdf = new DOMPDF($options);
	$contxt = stream_context_create([ 
    'ssl' => [ 
        'verify_peer' => FALSE, 
        'verify_peer_name' => FALSE,
        'allow_self_signed'=> TRUE
    ] 
]);
$dompdf->setHttpContext($contxt);
	$dompdf->set_paper("A4","Portrait");
	$dompdf->loadHtml($html);
	$dompdf->render();
	$dompdf->stream('patient_report.pdf');
?>