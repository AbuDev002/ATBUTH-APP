<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Add New User";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
<div class="container">
	<?php include_once('incs/upnavbar.php');?>
	<div class="row" style="background: #f5f5f5;">
		<?php include_once('incs/sidemenu.php');?>
		<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
			<?php
			include_once('connection.php');
			if(isset($_POST['btnAddClinic'])){
				$clinic_name = $_POST['clinic_name'];
				
				$clinic_name = mysqli_real_escape_string($conms,$clinic_name);
				
				if(empty($clinic_name)){
					echo "<p class='alert alert-danger'>Please enter clinic name!</p>";
				}else{
					include_once('connection.php');
					$addclinnic_qry = mysqli_query($conms,"INSERT INTO tbl_clinics (clinic_name)  VALUES('".$clinic_name."')");
					if($addclinnic_qry){
						echo "<p class='alert alert-success'>Clinic Added Successfully!</p>";
					}else{
						echo "<p class='alert alert-danger'>Unable to add clinic</p>";
					}
				}
			}
			?>
			<form action="" method="post">
				<div class="card">
					<div class="card-header"><span class="fa fa-plus"></span> Clinic Details</div>
					<div class="card-body">
						<div class="row">
							<div class="col-md-6">
								<fieldset class="scheduler-border">
									<legend class="scheduler-border"><strong>Add New Clinic</strong></legend>
									<div class="form-group">
										<input type="text" name="clinic_name" class="form-control" autocomplete="off" value="<?php echo isset($_POST['clinic_name']) ? $_POST['clinic_name'] : '' ?>" placeholder="Enter clinic name...">
									</div>
									<div class="form-group">
										<button type="submit" name="btnAddClinic" class="btn btn-primary">Add Clinic</button>
									</div>

								</fieldset>
							</div>
							<div class="col-md-6">
								<fieldset class="scheduler-border">
									<legend class="scheduler-border"><strong>List of Clinic</strong></legend>
									<div class="message-show"></div>
									<table class="table table-bordered table-responsive table-striped table-hover custom_table" style="width:100%;">
					 	<thead>
						 	<tr>
						 		<th>S/N</th>
						 		<th>Name of Clinic</th>
						 		<th></th>
						 		<th></th>
						 	</tr>
					 	</thead>
					 	<tbody>
					 	<?php 
					 		$count = 0;
					 		
					 			include_once('connection.php');
					 			$getclinic_sql = mysqli_query($conms,"select * from tbl_clinics");
					 			while($rows_rs = mysqli_fetch_array($getclinic_sql)){
					 			$count++;
					 			
							 	?>
							 	<tr>
							 		 <td style="display: none;" class="clinic_id"><?php echo $rows_rs['id'];?></td>
							 		<td><?php echo $count;?></td>
							 		<td><?php echo $rows_rs['clinic_name'];?></td>
									<?php if($_SESSION['account_type'] == 'Superadmin'){?>
							 		<td><a onclick="return confirm('Are you sure to delete');" href="deleteclinic.php?deleteclinic=<?php echo $rows_rs['id'];?>" title="Delete"><i class="fa fa-trash"></i></a></td>
							 		<td><a href="#" title="Edit" class="ClinicEdit_btn"><i class="fa fa-edit"></i></a></td>
									<?php }?>
								</tr>
							<?php } ?>
					 </tbody>
					 </table>
								</fieldset>
							</div>
						</div>

					</div>
				</div>

			</form>
		</div>
	</div>
	<?php include_once('modals/clinics/editclinic.php');?>
	<?php include_once('incs/footer.php');?>
	<script>
    //update clinic
        $('#UpdateClinic').click(function(e){
            e.preventDefault();
            var clinic_id = $('#clinicid_edit').val();
            var clinic_name = $('.clinic_name').val();
            $.ajax({
                url:'app/clinics/UpdateChanges.php',
                type:'POST',
                data:{
                    'checking_update':true,
                    'clinic_id':clinic_id,
                    'clinic_name':clinic_name
                },
                success: function(response){
                    $('#EditClinictModal').modal('hide');
                    $('.message-show').append('\<div class="alert alert-success alert-dismissible fade show" role="alert">\
                  <strong>Hey!</strong> '+response+'\
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\
                  </div>\
                  ');
                   
                }
            });

        });
    //fetch clinic details for editing
          $(document).on("click",".ClinicEdit_btn", function(){
            var clinic_id = $(this).closest('tr').find('.clinic_id').text();
            $.ajax({
                url:'app/clinics/updateClinic.php',
                type:'POST',
                data:{
                    'checking_edit':true,
                    'clinic_id':clinic_id
                },
                success: function(response){
                    $.each(response, function(key, clinicedit) {
                        $('#clinicid_edit').val(clinicedit['id']);
                        $('.clinic_name').val(clinicedit['clinic_name']);
                       
                    });

                    $('#EditClinictModal').modal('show');
                }
            });
        });
</script>
