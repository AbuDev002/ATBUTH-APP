-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2021 at 12:45 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atbuth`
--

-- --------------------------------------------------------

--
-- Table structure for table `antibiotics`
--

CREATE TABLE `antibiotics` (
  `id` int(11) NOT NULL,
  `antibiotic_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `antibiotics`
--

INSERT INTO `antibiotics` (`id`, `antibiotic_name`) VALUES
(1, 'Ampicillin'),
(2, 'Ampiclox'),
(3, 'Erythromycin'),
(4, 'Ceporex'),
(5, 'Gentamycin'),
(6, 'Chloramphenicol'),
(8, 'Ciprofloxacin'),
(9, 'Ofloxacin'),
(10, 'Rocephin'),
(11, 'Streptomycin'),
(12, 'Penicillin'),
(13, 'Augmentin'),
(14, 'Rifampicin'),
(15, 'Amoxicillin'),
(16, 'Cotrimoxazole'),
(17, 'Nalidixic acid'),
(18, 'Cefotaxime'),
(19, 'Pefloxacin'),
(20, 'Rifaximin');

-- --------------------------------------------------------

--
-- Table structure for table `culture`
--

CREATE TABLE `culture` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `logging_history`
--

CREATE TABLE `logging_history` (
  `id` int(11) NOT NULL,
  `logindate` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `time_in` varchar(100) NOT NULL,
  `time_out` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logging_history`
--

INSERT INTO `logging_history` (`id`, `logindate`, `email`, `name`, `time_in`, `time_out`) VALUES
(1, '2021-01-31', 'user1@abuth.bh', 'Abubakar Ahmad', '06:54:01', '18:52:22'),
(2, '2021-01-31', 'admin@abuth.bh', 'Super Administrator', '06:56:32', '14:36:08'),
(3, '2021-01-31', 'user1@abuth.bh', 'Abubakar Ahmad', '09:57:49', '18:52:22'),
(4, '2021-01-31', 'user1@abuth.bh', 'Abubakar Ahmad', '14:12:19', '18:52:22'),
(5, '2021-01-31', 'admin@abuth.bh', 'Super Administrator', '15:07:44', '14:36:08'),
(6, '2021-01-31', 'user1@abuth.bh', 'Abubakar Ahmad', '19:09:56', '18:52:22'),
(7, '2021-01-31', 'admin@abuth.bh', 'Super Administrator', '19:10:51', '14:36:08'),
(8, '2021-01-31', 'user1@abuth.bh', 'Abubakar Ahmad', '20:15:43', '18:52:22'),
(9, '2021-02-02', 'admin@abuth.bh', 'Super Administrator', '08:50:44', '14:36:08'),
(10, '2021-02-04', 'admin@abuth.bh', 'Super Administrator', '15:41:12', '14:36:08'),
(11, '2021-02-06', 'admin@abuth.bh', 'Super Administrator', '15:31:04', '14:36:08'),
(12, '2021-02-08', 'user2@abuth.bh', 'Abubakar Ahmad Yusuf', '15:48:45', '15:49:06'),
(13, '2021-02-08', 'user1@abuth.bh', 'Abubakar Ahmad', '15:50:11', '18:52:22'),
(14, '2021-02-08', 'admin@abuth.bh', 'Super Administrator', '17:47:51', '14:36:08'),
(15, '2021-02-08', 'user1@abuth.bh', 'Abubakar Ahmad', '19:32:43', '18:52:22'),
(16, '2021-02-08', 'user1@abuth.bh', 'Abubakar Ahmad', '19:34:18', '18:52:22'),
(17, '2021-02-08', 'admin@abuth.bh', 'Super Administrator', '19:38:00', '14:36:08'),
(18, '2021-02-08', 'admin@abuth.bh', 'Super Administrator', '20:06:58', '14:36:08'),
(19, '2021-02-09', 'admin@abuth.bh', 'Super Administrator', '08:31:10', '14:36:08'),
(20, '2021-02-09', 'admin@abuth.bh', 'Super Administrator', '10:07:22', '14:36:08'),
(21, '2021-02-09', 'admin@abuth.bh', 'Super Administrator', '10:08:53', '14:36:08'),
(22, '2021-02-09', 'user1@abuth.bh', 'Abubakar Ahmad', '10:10:35', '18:52:22'),
(23, '2021-02-09', 'admin@abuth.bh', 'Super Administrator', '11:41:38', '14:36:08'),
(24, '2021-02-10', 'admin@abuth.bh', 'Super Administrator', '20:23:48', '14:36:08'),
(25, '2021-03-17', 'admin@abuth.bh', 'Super Administrator', '10:04:28', '14:36:08'),
(26, '2021-03-28', 'admin@abuth.bh', 'Super Administrator', '11:24:11', '14:36:08'),
(27, '2021-03-28', 'admin@abuth.bh', 'Super Administrator', '15:29:54', '14:36:08'),
(28, '2021-03-28', 'user1@abuth.bh', 'Abubakar Ahmad', '20:57:01', '18:52:22'),
(29, '2021-04-26', 'admin@abuth.bh', 'Super Administrator', '10:39:58', '14:36:08'),
(30, '2021-04-26', 'admin@abuth.bh', 'Super Administrator', '10:41:03', '14:36:08'),
(31, '2021-05-16', 'admin@abuth.bh', 'Super Administrator', '12:28:09', '14:36:08'),
(32, '2021-05-25', 'admin@abuth.bh', 'Super Administrator', '12:43:38', '14:36:08'),
(33, '2021-05-26', 'admin@abuth.bh', 'Super Administrator', '08:48:49', '14:36:08'),
(34, '2021-05-26', 'admin@abuth.bh', 'Super Administrator', '16:04:11', '14:36:08'),
(35, '2021-05-27', 'admin@abuth.bh', 'Super Administrator', '08:54:36', '14:36:08'),
(36, '2021-05-27', 'admin@abuth.bh', 'Super Administrator', '15:42:04', '14:36:08'),
(37, '2021-05-27', 'admin@abuth.bh', 'Super Administrator', '15:42:04', '14:36:08'),
(38, '2021-05-27', 'admin@abuth.bh', 'Super Administrator', '15:45:39', '14:36:08'),
(39, '2021-05-28', 'admin@abuth.bh', 'Super Administrator', '08:11:16', '14:36:08'),
(40, '2021-05-28', 'admin@abuth.bh', 'Super Administrator', '14:52:31', '14:36:08'),
(41, '2021-05-29', 'admin@abuth.bh', 'Super Administrator', '10:31:44', '14:36:08'),
(42, '2021-05-31', 'admin@abuth.bh', 'Super Administrator', '09:05:11', '14:36:08'),
(43, '2021-06-01', 'admin@abuth.bh', 'Super Administrator', '16:00:57', '14:36:08'),
(44, '2021-06-01', 'admin@abuth.bh', 'Super Administrator', '16:19:09', '14:36:08'),
(45, '2021-06-03', 'admin@abuth.bh', 'Super Administrator', '08:37:17', '14:36:08'),
(46, '2021-06-07', 'admin@abuth.bh', 'Super Administrator', '09:38:42', '14:36:08'),
(47, '2021-06-09', 'admin@abuth.bh', 'Super Administrator', '14:41:28', '14:36:08'),
(48, '2021-06-09', 'admin@abuth.bh', 'Super Administrator', '19:15:52', '14:36:08'),
(49, '2021-06-10', 'admin@abuth.bh', 'Super Administrator', '08:57:37', '14:36:08'),
(50, '2021-06-11', 'admin@abuth.bh', 'Super Administrator', '18:41:04', '14:36:08'),
(51, '2021-06-12', 'admin@abuth.bh', 'Super Administrator', '08:47:05', '14:36:08'),
(52, '2021-06-21', 'admin@abuth.bh', 'Super Administrator', '08:57:51', '14:36:08'),
(53, '2021-06-22', 'admin@abuth.bh', 'Super Administrator', '10:50:45', '14:36:08'),
(54, '2021-06-22', 'user1@abuth.bh', 'Abubakar Ahmad', '18:52:03', '18:52:22'),
(55, '2021-06-23', 'admin@abuth.bh', 'Super Administrator', '15:24:35', '14:36:08'),
(56, '2021-06-24', 'admin@abuth.bh', 'Super Administrator', '12:36:37', '14:36:08'),
(57, '2021-06-24', 'admin@abuth.bh', 'Super Administrator', '12:46:19', '14:36:08'),
(58, '2021-06-25', 'admin@abuth.bh', 'Super Administrator', '08:53:36', '14:36:08'),
(59, '2021-07-26', 'admin@abuth.bh', 'Super Administrator', '15:58:15', '14:36:08'),
(60, '2021-07-26', 'admin@abuth.bh', 'Super Administrator', '18:16:47', '14:36:08'),
(61, '2021-07-26', 'admin@abuth.bh', 'Super Administrator', '18:36:22', '14:36:08'),
(62, '2021-07-27', 'admin@abuth.bh', 'Super Administrator', '08:01:53', '14:36:08'),
(63, '2021-07-27', 'admin@abuth.bh', 'Super Administrator', '13:57:59', '14:36:08'),
(64, '2021-07-28', 'admin@abuth.bh', 'Super Administrator', '09:25:45', '14:36:08'),
(65, '2021-07-28', 'admin@abuth.bh', 'Super Administrator', '20:56:12', '14:36:08'),
(66, '2021-07-29', 'admin@abuth.bh', 'Super Administrator', '08:18:42', '14:36:08'),
(67, '2021-07-29', 'admin@abuth.bh', 'Super Administrator', '09:56:57', '14:36:08'),
(68, '2021-07-29', 'admin@abuth.bh', 'Super Administrator', '12:39:32', '14:36:08'),
(69, '2021-07-30', 'admin@abuth.bh', 'Super Administrator', '09:41:02', 'Not Available'),
(70, '2021-07-30', 'admin@abuth.bh', 'Super Administrator', '11:18:42', 'Not Available'),
(71, '2021-07-31', 'admin@abuth.bh', 'Super Administrator', '08:22:05', 'Not Available'),
(72, '2021-08-01', 'admin@abuth.bh', 'Super Administrator', '08:13:00', 'Not Available'),
(73, '2021-08-02', 'admin@abuth.bh', 'Super Administrator', '08:17:40', 'Not Available'),
(74, '2021-08-02', 'admin@abuth.bh', 'Super Administrator', '12:50:57', 'Not Available'),
(75, '2021-08-02', 'admin@abuth.bh', 'Super Administrator', '13:09:55', 'Not Available'),
(76, '2021-08-02', 'admin@abuth.bh', 'Super Administrator', '16:50:57', 'Not Available'),
(77, '2021-08-02', 'admin@abuth.bh', 'Super Administrator', '17:00:04', 'Not Available'),
(78, '2021-08-04', 'admin@abuth.bh', 'Super Administrator', '08:27:21', 'Not Available'),
(79, '2021-08-05', 'admin@abuth.bh', 'Super Administrator', '15:40:24', 'Not Available'),
(80, '2021-08-06', 'admin@abuth.bh', 'Super Administrator', '08:23:03', 'Not Available'),
(81, '2021-08-07', 'admin@abuth.bh', 'Super Administrator', '19:39:39', 'Not Available'),
(82, '2021-08-09', 'admin@abuth.bh', 'Super Administrator', '09:42:47', 'Not Available'),
(83, '2021-09-11', 'admin@abuth.bh', 'Super Administrator', '07:51:42', 'Not Available'),
(84, '2021-09-14', 'admin@atbuth.bh', 'Super Administrator', '08:38:07', '12:40:59'),
(85, '2021-09-17', 'admin@atbuth.bh', 'Super Administrator', '10:46:53', '12:40:59'),
(86, '2021-09-17', 'admin@atbuth.bh', 'Super Administrator', '23:34:06', '12:40:59'),
(87, '2021-09-19', 'admin@atbuth.bh', 'Super Administrator', '07:19:29', '12:40:59'),
(88, '2021-09-20', 'admin@atbuth.bh', 'Super Administrator', '09:42:15', '12:40:59'),
(89, '2021-09-20', 'admin@atbuth.bh', 'Super Administrator', '09:53:15', '12:40:59'),
(90, '2021-09-20', 'admin@atbuth.bh', 'Super Administrator', '16:05:46', '12:40:59'),
(91, '2021-09-22', 'admin@atbuth.bh', 'Super Administrator', '10:56:01', '12:40:59'),
(92, '2021-09-22', 'admin@atbuth.bh', 'Super Administrator', '13:28:53', '12:40:59'),
(93, '2021-09-23', 'admin@atbuth.bh', 'Super Administrator', '12:00:01', '12:40:59'),
(94, '2021-09-30', 'admin@atbuth.bh', 'Super Administrator', '11:43:53', '12:40:59'),
(95, '2021-09-30', 'admin@atbuth.bh', 'Super Administrator', '11:49:51', '12:40:59'),
(96, '2021-09-30', 'admin@atbuth.bh', 'Super Administrator', '11:57:47', '12:40:59'),
(97, '2021-09-30', 'admin@atbuth.bh', 'Super Administrator', '12:14:18', '12:40:59'),
(98, '2021-09-30', 'admin@atbuth.bh', 'Super Administrator', '12:15:27', '12:40:59'),
(99, '2021-09-30', 'admin@atbuth.bh', 'Super Administrator', '12:20:49', '12:40:59');

-- --------------------------------------------------------

--
-- Table structure for table `macroscopy_urine`
--

CREATE TABLE `macroscopy_urine` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `microscopy`
--

CREATE TABLE `microscopy` (
  `id` int(11) NOT NULL,
  `microscopy_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `othername` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` longtext NOT NULL,
  `phoneno` varchar(100) NOT NULL,
  `hospital_no` varchar(100) NOT NULL,
  `lab_no` varchar(100) NOT NULL,
  `ward_clinic` varchar(100) NOT NULL,
  `spacemen` varchar(100) NOT NULL,
  `consultant` varchar(100) NOT NULL,
  `bedno` varchar(100) NOT NULL,
  `clinical_diagnosis` varchar(100) NOT NULL,
  `doctor` varchar(100) NOT NULL,
  `unit_no` varchar(100) NOT NULL,
  `creation_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `surname`, `firstname`, `othername`, `age`, `gender`, `address`, `phoneno`, `hospital_no`, `lab_no`, `ward_clinic`, `spacemen`, `consultant`, `bedno`, `clinical_diagnosis`, `doctor`, `unit_no`, `creation_date`) VALUES
(1, 'Ahmad', 'Abubakar', 'Yusuf', 30, 'Male', 'Fed Poly Bauchi', '', '', '', '', '', '', '', '', '', '', '2021-01-31 09:06:01'),
(2, 'Fatima', 'Musa', 'Muhammad', 19, 'Female', 'Gwallaga Bauchi', '', '48438', 'MBlab39384', '', '', '', '', '', '', '', '2021-01-31 12:24:28'),
(3, 'Ahmad', 'Ibrahim', 'Muhammed', 31, 'Male', 'Investment complex bauchi', '', 'Abuth9384', 'micro39484', '', '', '', '', '', '', '', '2021-01-31 14:20:40'),
(4, 'Mustpha', 'Adamu', '', 23, 'Male', 'Bauchi', '', 'amsd94848', '48474', '', '', '', '', '', '', '', '2021-01-31 14:21:22'),
(5, 'Sabo', 'Khalid', 'Boi', 34, 'Male', 'Bauchi', '', '48574', '59494', '', '', '', '', '', '', '', '2021-01-31 14:22:32'),
(6, 'Musa', 'Ketwuwet', '', 33, 'Male', 'Plataeu', '', '484774', '389484', '', '', '', '', '', '', '', '2021-01-31 14:23:13'),
(8, 'John', 'Billy', '', 29, 'Male', 'Bauchi', '', '494848', '394834', '', '', '', '', '', '', '', '2021-01-31 14:24:00'),
(12, 'Sadiq', 'Sulaiman', 'Musa', 34, 'Male', 'Federal Lowcoast Bauchi', '09084747438', 'TH48493', '4858', 'Sani Same', 'Fiver', 'Dr Musa', '6', 'Fiver', 'Dr Musa', '043', '2021-07-27 07:03:32'),
(17, 'Muhmmad', 'Lukman', '', 36, 'Male', 'Bauchi', '08036924738', '090104018', '', '', '', '', '', '', 'Prof Zailani', '', '2021-09-30 11:02:47');

-- --------------------------------------------------------

--
-- Table structure for table `patient_antibiotic_report`
--

CREATE TABLE `patient_antibiotic_report` (
  `id` int(11) NOT NULL,
  `antibiotic_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `test1` varchar(100) NOT NULL,
  `test2` varchar(10) NOT NULL,
  `test3` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_antibiotic_report`
--

INSERT INTO `patient_antibiotic_report` (`id`, `antibiotic_id`, `patient_id`, `test1`, `test2`, `test3`) VALUES
(3, 3, 3, 'I', '', ''),
(5, 5, 1, 'S', '', ''),
(6, 2, 1, 'R', '', ''),
(7, 3, 2, 'I', '', ''),
(8, 3, 1, 'R', '', ''),
(13, 3, 1, 'S', '', ''),
(14, 5, 1, 'S', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_general`
--

CREATE TABLE `tbl_general` (
  `id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_general`
--

INSERT INTO `tbl_general` (`id`, `item_name`) VALUES
(1, 'URINALYSYS'),
(2, 'MICROSCOPY SPECIAL'),
(3, 'MICROSCOPY GENERAL'),
(4, 'CULTURE AND SENSITIVITY'),
(5, 'SEROLOGY'),
(6, 'BLOOD'),
(7, 'STOOL'),
(8, 'URINE'),
(9, 'CSF'),
(10, 'SKIN/TISSUE'),
(11, 'SPUTUM'),
(12, 'ASPIRATE'),
(13, 'MICROSCOPY'),
(14, 'MALARIA PARASITE'),
(15, 'MICROFILARIA'),
(16, 'WIDAL TEST'),
(17, 'Hbs Ag'),
(18, 'HCV'),
(19, 'RF'),
(20, 'ASO TITRE'),
(21, 'RVS'),
(22, 'HBeAb'),
(23, 'HBeAg'),
(24, 'VDRL');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient_parasitology_report`
--

CREATE TABLE `tbl_patient_parasitology_report` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `date_sample_collection` varchar(100) NOT NULL,
  `time_sample_collection` varchar(100) NOT NULL,
  `reciept_no` varchar(100) NOT NULL,
  `clinical_diagnosis` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `spacemen` varchar(100) NOT NULL,
  `investigation` int(11) NOT NULL,
  `report_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_patient_parasitology_report`
--

INSERT INTO `tbl_patient_parasitology_report` (`id`, `patient_id`, `date_sample_collection`, `time_sample_collection`, `reciept_no`, `clinical_diagnosis`, `comment`, `spacemen`, `investigation`, `report_date`) VALUES
(1, 1, '12/07/2021', '1:15pm', '857574', '', 'Satisfactory', 'Blood', 1, '2021-08-01 06:51:42'),
(2, 2, '16/07/2021', '7:20am', '857574', '', 'Satisfactory', 'Blood', 1, '2021-08-01 06:51:25'),
(3, 5, '25/07/2021', '2:30pm', '857574', '', 'Satisfactory', 'Urine', 1, '2021-08-01 06:51:32'),
(4, 5, '14/07/2021', '4:00pm', '857574', '', 'Satisfactory', 'Urine', 1, '2021-08-01 06:51:53'),
(13, 1, '2021-08-01', '02:03', '4556565', '', 'Satisfactory', 'Blood', 5, '2021-08-01 11:02:58'),
(14, 1, '2021-08-06', '07:25', '47577', '', 'The result of the report is good', 'Sputum', 3, '2021-08-06 06:26:03'),
(16, 1, '2021-08-07', '08:39', '87574', '', 'The report is very good', 'Aspirate', 7, '2021-08-06 06:39:44'),
(17, 1, '2021-09-11', '12:05', '453454', '', 'the lab result is very good. keep it up', 'Sputum', 2, '2021-09-11 11:05:53'),
(18, 1, '2021-09-11', '13:04', '65454', '', 'rtergfsgf', 'CSF', 1, '2021-09-11 12:04:56'),
(19, 1, '2021-09-11', '13:07', '76878978', '', 'ertrtwtr', 'Aspirate', 2, '2021-09-11 12:07:26'),
(20, 1, '2021-09-11', '16:10', '', 'ghonorrhoea', 'the result is bad bad bad', 'Blood', 7, '2021-09-30 10:16:31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient_semen_report`
--

CREATE TABLE `tbl_patient_semen_report` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `date_produce` varchar(100) NOT NULL,
  `time_produce` varchar(100) NOT NULL,
  `time_recieve` varchar(100) NOT NULL,
  `time_examine` varchar(100) NOT NULL,
  `semen_volume` varchar(100) NOT NULL,
  `appearance` varchar(100) NOT NULL,
  `consistency` varchar(100) NOT NULL,
  `liquifaction` varchar(100) NOT NULL,
  `ph` varchar(100) NOT NULL,
  `concentration` varchar(100) NOT NULL,
  `msc` varchar(100) NOT NULL,
  `fsc` varchar(100) NOT NULL,
  `smi` varchar(100) NOT NULL,
  `report_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_patient_semen_report`
--

INSERT INTO `tbl_patient_semen_report` (`id`, `patient_id`, `date_produce`, `time_produce`, `time_recieve`, `time_examine`, `semen_volume`, `appearance`, `consistency`, `liquifaction`, `ph`, `concentration`, `msc`, `fsc`, `smi`, `report_date`) VALUES
(1, 4, '', 'Modaay', 'Tuesday', 'Wednesday', '', '', '', '', '', '', '', '', '', '2021-07-29 07:06:00'),
(2, 4, '', 'Modaay', 'Tuesday', 'Wednesday', '20', 'Whaite', '3', 'Satisfactory', '43', 'Normal', 'normal', 'normal', 'normal', '2021-07-29 07:06:52'),
(3, 1, '', 'dfgdfg', 'dfgfg', 'ghhjghjg', 'fgfg', 'fgdg', 'dhfgh', 'errty', 'gfhgf', 'dfgfh', 'hrtyr', 'dg', 'rtrty', '2021-08-05 08:47:55'),
(4, 1, '', 'the', 'the', 'the', 'of the', 'of the', 'of the', 'of the', 'of the', 'of the', 'of the', 'of the', 'of the', '2021-08-05 08:50:02'),
(5, 1, '', '07:29', '08:29', '11:29', '200', 'fsdgfs', 'fgdfg', 'fghg', 'gfghgf', 'dfgfgd', 'hgh', 'dfgfg', 'dhgf', '2021-08-06 06:29:27'),
(6, 1, '', '10:29', '11:30', '01:30', '600', 'dfgfg', 'sdfdfg', 'fgh', 'erttr', 'rtrt', 'fghfg', 'dffgh', 'fghgf', '2021-08-06 06:30:16'),
(7, 1, '2021-09-11', '15:21', '14:21', '16:21', '346654654', 'good', 'wetert', 'wertetr', 'wertetry', 'eryrty', 'good', 'good', 'good', '2021-09-11 14:21:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient_sensitivity_report`
--

CREATE TABLE `tbl_patient_sensitivity_report` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `request_type` varchar(100) NOT NULL,
  `app_microscopy` varchar(100) NOT NULL,
  `micro_serology` varchar(100) NOT NULL,
  `culture_yeilded` varchar(100) NOT NULL,
  `date_recieved` varchar(100) NOT NULL,
  `date_issued` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_patient_sensitivity_report`
--

INSERT INTO `tbl_patient_sensitivity_report` (`id`, `patient_id`, `request_type`, `app_microscopy`, `micro_serology`, `culture_yeilded`, `date_recieved`, `date_issued`) VALUES
(1, 1, '2', 'perfect', 'perfect', 'perfect', '2021-07-29', '2021-07-29'),
(2, 1, '5', 'nice result', 'nice result', 'nice result', '2021-07-29', '2021-07-29'),
(15, 3, '2', 'sdfdsf', 'sdfds', 'dfgdf', '2021-08-05', '2021-08-14'),
(16, 2, '2', 'satisfactory', 'satisfactory', 'satisfactory', '2021-08-05', '2021-08-09'),
(17, 1, '3', 'eryrt', 'etr', 'rtyty', '2021-08-05', '2021-08-06'),
(18, 1, '12', 'the good', 'the good', 'the good', '2021-08-12', '2021-08-25');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient_serology_report`
--

CREATE TABLE `tbl_patient_serology_report` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `investigation` varchar(100) NOT NULL,
  `result` text NOT NULL,
  `report_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_patient_serology_report`
--

INSERT INTO `tbl_patient_serology_report` (`id`, `patient_id`, `investigation`, `result`, `report_date`) VALUES
(1, 1, '1', 'Normal', '2021-07-29 07:04:27'),
(2, 1, '2', 'ades', '2021-07-29 10:45:51'),
(4, 1, '2', 'eyrytrr', '2021-08-05 08:22:29'),
(6, 2, '8', 'The second report is very good', '2021-08-05 08:25:00'),
(7, 1, '2', 'The result is perfect and good', '2021-09-22 11:30:02'),
(31, 1, '6', 'The result is not as bad as we thought ', '2021-09-21 14:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `account_type` varchar(100) NOT NULL,
  `account_staus` int(11) NOT NULL DEFAULT 0,
  `sid` varchar(100) NOT NULL,
  `lastlogin` varchar(100) NOT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(4) UNSIGNED ZEROFILL NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`name`, `username`, `password`, `mobile`, `email`, `gender`, `image`, `account_type`, `account_staus`, `sid`, `lastlogin`, `lastupdated`, `user_id`) VALUES
('Super Administrator', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', '-', 'admin@atbuth.bh', '', '', 'Superadmin', 0, 'e22be620df66041f9f17fed62a515f05', '2021-09-30 11:20:49', '2021-09-30 10:20:49', 0001),
('Abubakar Ahmad', 'user1', '5f4dcc3b5aa765d61d8327deb882cf99', '', 'user1@atbuth.bh', '', '', 'User', 0, '6b4f761140704d0c5d60d48023fede78', '2021-06-22 17:52:03', '2021-09-14 06:37:48', 0002),
('Abubakar Ahmad Yusuf', 'user2', '5f4dcc3b5aa765d61d8327deb882cf99', '08032343030', 'user2@atbuth.bh', 'Male', '', 'User', 0, '1cdb47c73a92a186a934055a8a31f1f1', '2021-02-08 15:48:45', '2021-09-14 06:37:53', 0003);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `antibiotics`
--
ALTER TABLE `antibiotics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `culture`
--
ALTER TABLE `culture`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logging_history`
--
ALTER TABLE `logging_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `macroscopy_urine`
--
ALTER TABLE `macroscopy_urine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `microscopy`
--
ALTER TABLE `microscopy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_antibiotic_report`
--
ALTER TABLE `patient_antibiotic_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_general`
--
ALTER TABLE `tbl_general`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_patient_parasitology_report`
--
ALTER TABLE `tbl_patient_parasitology_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_patient_semen_report`
--
ALTER TABLE `tbl_patient_semen_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_patient_sensitivity_report`
--
ALTER TABLE `tbl_patient_sensitivity_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_patient_serology_report`
--
ALTER TABLE `tbl_patient_serology_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`username`,`mobile`,`email`),
  ADD KEY `gender` (`gender`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `antibiotics`
--
ALTER TABLE `antibiotics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `culture`
--
ALTER TABLE `culture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logging_history`
--
ALTER TABLE `logging_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `macroscopy_urine`
--
ALTER TABLE `macroscopy_urine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `microscopy`
--
ALTER TABLE `microscopy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `patient_antibiotic_report`
--
ALTER TABLE `patient_antibiotic_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_general`
--
ALTER TABLE `tbl_general`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_patient_parasitology_report`
--
ALTER TABLE `tbl_patient_parasitology_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_patient_semen_report`
--
ALTER TABLE `tbl_patient_semen_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_patient_sensitivity_report`
--
ALTER TABLE `tbl_patient_sensitivity_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_patient_serology_report`
--
ALTER TABLE `tbl_patient_serology_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `user_id` int(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
