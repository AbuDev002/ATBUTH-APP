<?php
//fetch.php
include_once('connection.php');
$columns = array('product_name', 'stock_level', 'price');

$query = "SELECT * FROM products ";

if(isset($_POST["search"]["value"]))
{
 $query .= '
 WHERE product_name LIKE "%'.$_POST["search"]["value"].'%" 
 OR stock_level LIKE "%'.$_POST["search"]["value"].'%"
 OR price LIKE "%'.$_POST["search"]["value"].'%"  
 OR supplier_name LIKE "%'.$_POST["search"]["value"].'%"  
 ';
}

if(isset($_POST["order"]))
{
 $query .= 'ORDER BY '.$columns[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' 
 ';
}
else
{
 $query .= 'ORDER BY product_id DESC ';
}

$query1 = '';

if(@$_POST["length"] != -1)
{
 $query1 = 'LIMIT ' . @$_POST['start'] . ', ' . @$_POST['length'];
}

$number_filter_row = mysqli_num_rows(mysqli_query($conms, $query));

$result = mysqli_query($conms, $query . $query1);

$data = array();

while($row = mysqli_fetch_array($result))
{
 $sub_array = array();
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["product_id"].'" data-column="supplier_name">' . $row["supplier_name"] . '</div>';
  $sub_array[] = '<div contenteditable class="update" data-id="'.$row["product_id"].'" data-column="product_name">' . $row["product_name"] . '</div>';
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["product_id"].'" data-column="stock_level">' . $row["stock_level"] . '</div>';
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["product_id"].'" data-column="price">' . $row["price"] . '</div>';
 $sub_array[] = '<button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$row["product_id"].'"><i class="fa fa-trash"></i></button>';
 $data[] = $sub_array;
}

function get_all_data($conms)
{
 //include_once('connection.php');
 $query = "SELECT * FROM products ";
 $result = mysqli_query($conms, $query);
 return mysqli_num_rows($result);
}

$output = array(
 "draw"    => intval(@$_POST["draw"]),
 "recordsTotal"  =>  get_all_data($conms),
 "recordsFiltered" => $number_filter_row,
 "data"    => $data
);

echo json_encode($output);

?>
