<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Add New User";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
<div class="container">
	<?php include_once('incs/upnavbar.php');?>
	<div class="row" style="background: #f5f5f5;">
		<?php include_once('incs/sidemenu.php');?>
		<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
			<?php
			include_once('connection.php');
			if(isset($_POST['btnAddUser'])){
				$surname = $_POST['surname'];
				$firstname = $_POST['firstname'];
				$othername = $_POST['othername'];
				$age = $_POST['age'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$phoneno = $_POST['phoneno'];
				$hospital_no = $_POST['hospital_no'];
				$lab_no = $_POST['lab_no'];
				$ward_clinic = $_POST['ward_clinic'];
				$spacemen = $_POST['spacemen'];
				$consultant = $_POST['consultant'];
				$bedno = $_POST['bedno'];
				$clinic_diagnosis = $_POST['clinic_diagnosis'];
				$doctor = $_POST['doctor'];
				$unitno = $_POST['unitno'];

				$surname = mysqli_real_escape_string($conms,$surname);
				$firstname = mysqli_real_escape_string($conms,$firstname);
				$othername = mysqli_real_escape_string($conms,$othername);
				$age = mysqli_real_escape_string($conms,$age);
				$gender = mysqli_real_escape_string($conms,$gender);
				$address = mysqli_real_escape_string($conms,$address);
				$phoneno = mysqli_real_escape_string($conms,$phoneno);

				$ward_clinic = mysqli_real_escape_string($conms,$ward_clinic);
				$spacemen = mysqli_real_escape_string($conms,$spacemen);
				$consultant = mysqli_real_escape_string($conms,$consultant);
				$bedno = mysqli_real_escape_string($conms,$bedno);
				$clinic_diagnosis = mysqli_real_escape_string($conms,$clinic_diagnosis);
				$doctor = mysqli_real_escape_string($conms,$doctor);
				$unitno = mysqli_real_escape_string($conms,$unitno);
				$hospital_no = mysqli_real_escape_string($conms,$hospital_no);
				$lab_no = mysqli_real_escape_string($conms,$lab_no);


				if(empty($surname)){
					echo "<p class='alert alert-danger'>Please enter Patient names!</p>";
				}else{
					include_once('connection.php');
					$addpatient_qry = mysqli_query($conms,"INSERT INTO patients (surname,firstname,othername,age,gender,address,phoneno,hospital_no,lab_no,ward_clinic,spacemen,consultant,bedno,clinical_diagnosis,doctor,unit_no) VALUES('".$surname."','".$firstname."','".$othername."','".$age."','".$gender."','".$address."','".$phoneno."','".$hospital_no."','".$lab_no."','".$ward_clinic."','".$spacemen."','".$consultant."','".$bedno."','".$clinic_diagnosis."','".$doctor."','".$unitno."')");
					if($addpatient_qry){
						echo "<p class='alert alert-success'>Patient Added Successfully!</p>";
					}else{
						echo "<p class='alert alert-danger'>Unable to add patient</p>";
					}
				}
			}
			?>
			<form action="" method="post">
				<div class="card">
					<div class="card-header"><span class="fa fa-plus"></span> Add New Patient</div>
					<div class="card-body">
						<div class="row">
							<div class="col-md-6">
								<fieldset class="scheduler-border">
									<legend class="scheduler-border"><strong>Personal Details</strong></legend>
									<div class="form-group">
										<input type="text" name="surname" class="form-control" autocomplete="off" value="<?php echo isset($_POST['surname']) ? $_POST['surname'] : '' ?>" placeholder="Surname...">
									</div>

									<div class="form-group">
										<input type="text" name="firstname" class="form-control" autocomplete="off" placeholder="Firstname..." value="<?php echo isset($_POST['firstname']) ? $_POST['firstname'] : '' ?>" autocomplete="off">
									</div>

									<div class="form-group">
										<input type="text" name="othername" class="form-control" autocomplete="off" value="<?php echo isset($_POST['othername']) ? $_POST['othername'] : '' ?>" placeholder="Othername..." autocomplete="off">
									</div>
									<div class="form-group">
										<input type="text" name="age" class="form-control" autocomplete="off" value="<?php echo isset($_POST['age']) ? $_POST['age'] : '' ?>" placeholder="Age years/months...">
									</div>
									<div class="form-group">
										<select name="gender" id="" class="form-control" style="height:30px;padding-top:4px;">
											<option value="">--Select Gender--</option>
											<option <?php if(isset($_POST['gender']) && $_POST['gender'] =='Male') echo "selected='selected'";?> value="Male">Male</option>
											<option <?php if(isset($_POST['gender']) && $_POST['gender'] =='Female') echo "selected='selected'";?> value="Female">Female</option>
										</select>
									</div>
									<div class="form-group">
										<input type="text" name="address" class="form-control" autocomplete="off" value="<?php echo isset($_POST['address']) ? $_POST['address'] : '' ?>" placeholder="Address..." autocomplete="off">
									</div>

									<div class="form-group">
										<input type="text" name="phoneno" class="form-control" autocomplete="off" value="<?php echo isset($_POST['phoneno']) ? $_POST['phoneno'] : '' ?>" placeholder="Phone no...">
									</div>



								</fieldset>
							</div>
							<div class="col-md-6">
								<fieldset class="scheduler-border">
									<legend class="scheduler-border"><strong>Hospital Details</strong></legend>
									
									<div class="form-group">
										<input type="text" name="hospital_no" class="form-control" value="<?php echo isset($_POST['hospital_no']) ? $_POST['hospital_no'] : '' ?>" placeholder="Hospital No..." autocomplete="off">
									</div>
									<div class="form-group">
										<input type="text" name="unitno" class="form-control" value="<?php echo isset($_POST['unitno']) ? $_POST['unitno'] : '' ?>" placeholder="Unit No..." autocomplete="off">
									</div>
									<div class="form-group">
										
										<select  name="ward_clinic" id="ward_clinic" class="form-control selectpicker" data-live-search="true">
											<option>--Select Clinic--</option>
											<?php 
											include_once('connection.php');
											$get_clinic = mysqli_query($conms,"select * from tbl_clinics");
											while($clinic_list = mysqli_fetch_array($get_clinic)){
												$clinic_id = $clinic_list['id'];
												$clinic_name = $clinic_list['clinic_name'];


												?>
												<option value="<?php echo $clinic_name; ?>"><?php echo $clinic_name;?></option> 
											<?php } ?>
										</select>
										
									</div>
									<div class="form-group">
										<input type="text" name="bedno" class="form-control" value="<?php echo isset($_POST['bedno']) ? $_POST['bedno'] : '' ?>" placeholder="Bed No..." autocomplete="off">
									</div>
									<div class="form-group">
										<input type="text" name="lab_no" class="form-control" value="<?php echo isset($_POST['lab_no']) ? $_POST['lab_no'] : '' ?>" placeholder="Lab No..." autocomplete="off">
									</div>
									<div class="form-group">
										<select  name="spacemen" id="spacemen" class="form-control selectpicker" data-live-search="true">
											<option>--Select Spacimen--</option>
											<?php 
											include_once('connection.php');
											$get_spacimen = mysqli_query($conms,"select * from tbl_spacimens");
											while($spacimen_list = mysqli_fetch_array($get_spacimen)){
												$spacimen_id = $spacimen_list['id'];
												$spacimen_name = $spacimen_list['spacimen_name'];


												?>
												<option value="<?php echo $spacimen_name; ?>"><?php echo $spacimen_name;?></option> 
											<?php } ?>
										</select>
										
									</div>
									<div class="form-group">
										<input type="text" name="consultant" class="form-control" value="<?php echo isset($_POST['consultant']) ? $_POST['consultant'] : '' ?>" placeholder="Consultant/Doctor..." autocomplete="off">
									</div>
									<div class="form-group">
										<input type="text" name="clinic_diagnosis" class="form-control" value="<?php echo isset($_POST['clinic_diagnosis']) ? $_POST['clinic_diagnosis'] : '' ?>" placeholder="Clinical Diagnosis..." autocomplete="off">
									</div>
									<div class="form-group">
										<input type="text" name="doctor" class="form-control" value="<?php echo isset($_POST['doctor']) ? $_POST['doctor'] : '' ?>" placeholder="Doctor..." autocomplete="off">
									</div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary margin-bottom btn-block" name="btnAddUser"><i class="fa fa-plus"></i> Add Patient</button>
									</div>

								</fieldset>
							</div>
						</div>

					</div>
				</div>

			</form>
		</div>
	</div>

	<?php include_once('incs/footer.php');?>