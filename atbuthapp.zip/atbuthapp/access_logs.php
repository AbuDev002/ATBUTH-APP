<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Access Logs";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					     <div class="row">
                  
		                  <div class="col-md-12">
		                    <table class="table table-bordered table-hover custom_table" style="font-size:12px;">
		                    	<thead>
		                    	<tr>
		                    		<th colspan="5">Users Login Session</th>
		                    	</tr>
		                    	<tr>
		                    		<th>Name</th>
		                    		<th>Email</th>
		                    		<th>Date</th>
		                    		<th>Time In</th>
		                    		<th>Time Out</th>
		                    	</tr>
		                    	</thead>
		                    	<tbody>
		                    	<?php
                                include_once('connection.php');
                                $sql_loginhistory="SELECT * FROM logging_history";
                                $query_run=mysqli_query($conms,$sql_loginhistory);
                                while($row=mysqli_fetch_array($query_run)){
                             	 ?>
                             	 <tr>
                             	 	<td><?php echo $row['name'];?></td>
                             	 	<td><?php echo $row['email'];?></td>
                             	 	<td><?php echo $row['logindate'];?></td>
                             	 	<td><?php echo $row['time_in'];?></td>
                             	 	<td><?php echo $row['time_out'];?></td>
                             	 </tr>
                             	<?php }?>
                             	</tbody>
		                    </table>

		                    
		                  </div>
		            
		               </div>
					 </div>
				</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>