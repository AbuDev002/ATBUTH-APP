<?php
include_once('connection.php');
if(isset($_POST["id"]))
{
 $value = mysqli_real_escape_string($conms, $_POST["value"]);
 $query = "UPDATE products SET ".$_POST["column_name"]."='".$value."' WHERE product_id = '".$_POST["id"]."'";
 if(mysqli_query($conms, $query))
 {
  echo 'Data Updated';
 }
}
?>