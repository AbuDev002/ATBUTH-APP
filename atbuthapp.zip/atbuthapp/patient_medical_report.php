<?php
        session_start();
		ob_start();
		//error_reporting(1);
		require_once 'vendor/autoload.php';
		if(isset($_GET['pid'])){
			$pid = (int) $_GET['pid'];
		}
		
?>
<?php include_once('connection.php');?>

<!Doctype html>
<html>
	<head>
		<title>Patient Report Form</title>

		<style type="text/css">
			#container{
				width:100%;
				height:auto;
				margin:0px auto;
				margin-top:20px;
				text-indent:5px;
				font-size:12px;
                               
			}
				
			th#mdb{
				background-image:url("images/sch-logo.png") no-repeat;
				background-size:contain;
			}
			
			#report_details td{
				border:1px solid black;
				border-collapse:collapse;
			}
			
			.head{
				background:#91C5D4;
				}
		@page { 
				margin-top: 180px;
				margin-left: 50px;
				margin-right: 50px;
				margin-bottom: 50px;
				background-color: skyblue;
			 }
			#header { position: fixed; left: -45px; top: -180px; right: -45px; height: 100px; background-color: #f5f5f5; text-align: center; width:100%; }
			#footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 160px; background-color: #f5f5f5; }
			/*#footer .page:after { content: counter(page, upper-roman); }*/
			
			/*table#report_details{page-break-inside:avoid}*/
		  .paragraph{
		  	text-align: justify;
		  	line-height: 30px;
		  }

		  .left_area{
			  width:49%;
			  /* height:500px; */
			  float:left;
			  display:block;
			  min-height: 550px;
			 /* border:3px solid black;*/
			  /*border:1px solid black;*/
		  }
		  .right_area{
			  width:50%;
			  /* min-height:500px; */
			  /*border-left:1px solid black;*/
			  border-radius:10px;
			  float:right;
			  display:block;
			 /* border:3px solid black;*/
			  min-height: 550px;
		  }
		  .clear{
			  clear:both;
			  overflow: auto;
		  }
		  .tbl_antibiotics{
			  width:100%;
			  border:1px solid black;
			  border-spacing: -1px;
			  /*margin-top:20px;*/
		  }
		  .tbl_antibiotics td{
			  border:1px solid black;
			  
		  }

		  #isolates{
			  width:100%;
			  border-right:1px solid black;
			  border-top:0px;
			  border-bottom:0px;
			  border-left:0px;
			  border-right:0px;
			  border-spacing: -1px;
			  /*margin-top:20px;*/
		  }
		  #isolates td{
			  border:1px solid black;
			  
		  }

		 /* table#isolates td{
		  	 border:1px solid black;
		  }*/

			.box-tick{
				height: 25px;
				width:40px;
				border:1px solid black;
				margin:5px;
				margin-bottom: 0px;
				float-left;
			}
		</style>
	</head>
	
<body>
<div id="container">

<div id="header">
		<table align="center"  cellpadding="0"  width="100%" style="font-size:12px; border-collapse:collapse;">
			<tr>
				<td align="right" width="50"><img src="http://localhost/atbuthapp/images/abuthlogo.png" width="100" height="80" style="margin-top: 10px;"></td>
				<td align="center" colspan="2"><h1>ABUBAKAR TAFAWA BALEWA UNIVERSITY <br/> TEACHING HOSPITAL, BAUCHI</h1></td>
			</tr>
			<tr>
				
				<td colspan="3" align="center" valign="top" height="10"><h2 style="padding:0px; background:#29166F; color:#fff;">MICROBIOLOGY LABORATORY FORM</h2></td>
				
			</tr>
			
		</table>
		
</div>
	<div id="footer">
		<hr/>
	</div>

<table class="profit_list" width="100%" border="1" id="report_details" cellspacing="0" style="margin-top:-50px;font-size:12px;border-left:0px;">
	<?php
		include_once('connection.php');
		$patientname_sql = mysqli_query($conms,"select * from patients where id=$pid");
		$patient_data = mysqli_fetch_array($patientname_sql);
	?>
  <tr>
    <td style="height:30px;" valign="top">
    	<strong>SURNAME:</strong>
    	<p><?php echo strtoupper($patient_data['surname']);?></p>
    </td>
    <td valign="top">
    	<strong>FIRST NAME:</strong>
    	<p><?php echo strtoupper($patient_data['firstname']);?></p>
    </td>
	<td valign="top">
		<strong>AGE:</strong>
		<p><?php echo strtoupper($patient_data['age']);?></p>
	</td>
	<td valign="top">
		<strong>SEX:</strong>
		<p><?php echo strtoupper($patient_data['gender']);?></p>
	</td>
	<td valign="top">
		<strong>LAB NO:</strong>
		<p><?php echo strtoupper($patient_data['lab_no']);?></p>
	</td>
	<td valign="top">
		<strong>UNIT NO:</strong>
		<p><?php echo strtoupper($patient_data['unit_no']);?></p>
	</td>
  </tr>
  <tr>
  	<td style="height:50px;" valign="top">
		<strong>CONSULTANT:</strong>
		<p><?php echo strtoupper($patient_data['consultant']);?></p>
	</td>
	<td valign="top" colspan="2">
		<strong>NAME & SIGNATURE OF DOCTOR:</strong>
		<p><?php echo strtoupper($patient_data['doctor']);?></p>
	</td>
	<td valign="top">
		<strong>SPACIMEN:</strong>
		<p><?php echo strtoupper($patient_data['spacemen']);?></p>
	</td>
	<td valign="top">
		<strong>WARD/CLINIC:</strong>
		<p><?php echo strtoupper($patient_data['ward_clinic']);?></p>
	</td>
	<td valign="top">
		<strong>DATE OF REQUEST:</strong>
		<p><?php echo strtoupper($patient_data['creation_date']);?></p>
	</td>
  </tr>
  <tr>
  	<td style="height:30px;" colspan="6" valign="top">
  		<strong>CLINICAL DETAILS</strong>
  		<p></p>
  	</td>
  </tr>
  
</table>

<h3 style="padding:0px;margin:0px;">TYPES OF REQUEST:</h3>
<table class="request_type">
	<tr>
		<td width="50"><div class="box-tick"></div></td>
		<td>ANALYSIS</td>
	</tr>
	<tr>
		<td><div class="box-tick"></div></td>
		<td>MICROSCOPY (Special)</td>
	</tr>
	<tr>
		<td><div class="box-tick"></div></td>
		<td>MICROSCOPY (General)</td>
	</tr>
		<td><div class="box-tick"></div></td>
		<td>CULTURE AND SENSITIVITY</td>
	<tr>
		<td><div class="box-tick"></div></td>
		<td>SEROLOGY &nbsp; &nbsp;  <small style="font-size:12px;">RVS, HBsAg, hc/ab VDRL TPHA, Chlamydia, H.pylori Toxoplasma, Rheumatoid factor, Anti-HCV ,Aso titre</small></td>
	</tr>
</table>
<p style="font-size:28px;text-align:center;font-weight: bold;text-decoration: underline;padding:0px;margin:0px;"> THE REPORT </p>
<!-- <P style="font-size:12px;text-align:right"> 2347</P> -->
<div class="container">
		  	<div class="left_area">
		  		<br/>
		  		<br/>
		  		<div style="width:90%;height:50px;border:1px solid #000;margin-bottom:5px;">
		  			<p><strong>APPEARACE/MACROSCOPY:</strong></p>
		  		</div>
		  		<div style="width:90%;height:220px;border:1px solid #000;margin-bottom:5px;">
		  			<p><strong>MICROSCOPY/SEROLOGY REPORT:</strong></p>
		  		</div>
				
				<div style="width:90%;height:50px;border:1px solid #000;">
		  			<p><strong>CULTURE</strong></p>
		  		</div>
		  		<table style="border:1px solid black;border-collapse:collapse;width:91%;margin-top: 5px;">
		  			<tr>
		  				<td style="border: 1px solid black;height: 40px;" align="center" valign="top">DATE RECEIVED</td>
		  				<td style="border: 1px solid black;height: 40px;" align="center" valign="top">DATE ISSUED</td>
		  			</tr>
		  		</table>
				<div style="width:90%;height:50px;border:1px solid #000;margin-top: 5px;">
		  			<strong>NAME & SIGNATURE OF MED. LAB. SCIENTIST</strong>
		  		</div>
			</div>
		  	<div class="right_area">
			 	<p style="vertical-align: bottom;margin-bottom: 5px;padding-bottom: 0px;text-decoration: underline;"><strong>SENSITIVITY</strong></p>
		  		<table class="tbl_antibiotics">
				  	<thead>
						<tr>
						<td align="center"><strong>Antibiotic</strong></td>
						<td colspan="3">
							<table id="isolates">
								<tr>
									<td align="center" colspan="3"><strong>ISOLATES</strong></td>
								</tr>
								<tr>
									<td align="center"><strong>1</strong></td>
									<td align="center"><strong>2</strong></td>
									<td align="center"><strong>3</strong></td>
								</tr>
							</table>
						</td>
						</tr>
					</thead>
					<tbody>
					<?php
						include_once('connection.php');
						$sql_getantibiotics = mysqli_query($conms,"select * from antibiotics");
						while($list_antibiotics = mysqli_fetch_array($sql_getantibiotics)){
					?>
					<tr>
						<td>
						<?php 
							echo $list_antibiotics['antibiotic_name'];
						?>
						</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<?php } ?>
					<!-- <tr>
						<td>Data</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td>Data</td>
						<td></td>
						<td></td>
						<td></td>
					</tr> -->
					</tbody>
					
				</table>
				<p>S = Sensitive, R= Resistant, I = Intermediate</p>
				<div style="width:100%;height:100px;border:1px solid #000;margin-top: 5px;position:absolute;bottom:0px;top:405px;">
		  			<strong><i>CONSULTANT COMMENT</i></strong>
		  		</div>
			</div>
			<div class="clear"></div>
			
		  
</div>
</div>

</body>
</html>
<?php		
	$html = ob_get_clean();
	use Dompdf\Dompdf;
	use Dompdf\Options;
	require_once 'vendor/autoload.php';
	$options = new Options();
    $options->set('isRemoteEnabled', TRUE);
    $options->set('debugKeepTemp', TRUE);
    $options->set('isHtml5ParserEnabled', true);
	$dompdf = new DOMPDF($options);
	$contxt = stream_context_create([ 
    'ssl' => [ 
        'verify_peer' => FALSE, 
        'verify_peer_name' => FALSE,
        'allow_self_signed'=> TRUE
    ] 
]);
$dompdf->setHttpContext($contxt);
	$dompdf->set_paper("A4","Portrait");
	$dompdf->loadHtml($html);
	$dompdf->render();
	$dompdf->stream('patient_report.pdf');
?>