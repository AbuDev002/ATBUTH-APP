<?php
//$conms = @mysqli_connect('localhost','root','','abuth');
$conms = new mysqli("localhost", "root", "", "atbuth");
if ($conms->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') '
            . $mysqli->connect_error);
}
?>