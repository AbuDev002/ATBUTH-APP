<?php
include_once("../../connection.php");
	$sql = "SELECT * FROM tbl_patient_serology_report";
	$resultset = mysqli_query($conms, $sql) or die("database error:". mysqli_error($conms));
	
	$data = array();
    $sn = 0;
	while($rows = mysqli_fetch_assoc($resultset) ) {
	$sn++;
    ?>
<tr>
    <td><?php echo $sn;?></td>
    <td>
        <?php 
            $getpatient = mysqli_query($conms,"select * from patients WHERE id =".$rows['patient_id']."");
            $patientName = mysqli_fetch_array($getpatient);
            echo $patientName['surname'].' '.$patientName['firstname'].' '.$patientName['othername'];
        ?>
    </td>
    <td>
         <?php 
            $getInvest = mysqli_query($conms,"select * from tbl_general WHERE id =".$rows['investigation']."");
            $investName = mysqli_fetch_array($getInvest);
            echo $investName['item_name'];
        ?>    
    </td>
    <td><?php echo $rows['result'];?></td>
    <td style="width:40px;">
    <!-- <a href="#" class="btn btn-danger delete_report"><i class="fa fa-trash"></i></a> -->
    <button class="btn btn-danger seromp_report" id="<?php echo $rows['id'];?>"><span class="badge badge-danger badge-pill"><i class="fa fa-trash"></i></span></button>
    </td>
</tr>

<?php } ?>