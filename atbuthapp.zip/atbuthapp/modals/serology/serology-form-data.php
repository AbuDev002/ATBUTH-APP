<!-- Modal -->
<div class="modal take-report-modal animate__animated animate__zoomIn" id="TakeSerologyReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">SEROLOGY REPORT FORM</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">APPLICANT DETAILS</h5></center> -->
               
       
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-6 offset-md-3">
                    <form id="SerologyReportForm" action="">
                        
                    <div class="form-group">
                        <label>Investigation</label>
                        <select name="investigation" id="investigation" class="form-control selectpicker investigation" data-live-search="true">
                            <option value="">--Type of Request</option>
                           <?php 
                                include_once('connection.php');
                                $get_all_analysis = mysqli_query($conms,"select * from tbl_general");
                                while($analysis_list = mysqli_fetch_array($get_all_analysis)){
                                        $analysis_id = $analysis_list['id'];
                                        $analysis_name = $analysis_list['item_name'];
                                        
                                if (@$_GET['antibiotic'] == $analysis_id) {

                                    echo "<option value=\"".$analysis_id."\" selected='selected'>".$analysis_name." </option>"; 
                                    } else {
                                        echo "<option value=\"".$analysis_id."\">".$analysis_name."</option>";       
                                    }
                                }   
                                ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Result</label>
                       
                        <textarea name="invResult" id="invResult" class="form-control" cols="30" rows="5" placeholder="Enter result..."></textarea>
                    </div>
                     <div class="form-group">
                       <button class="btn btn-primary ladda-button" data-style="expand-right" data-size="s" data-spinner-color="#000" data-spinner-lines="5">Save Report</button>
                    </div>
                   </form>
                    </div>
                   <!--  <div class="col-md-8">
                        
                       <div class="" style="height:450px;width:100%;overflow:auto;">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Patient Name</th>
                                        <th>Investigation</th>
                                        <th>Report</th>
                                    </tr>
                                </thead>
                                <tbody id="serologyReportList">
                                    
                                </tbody>
                            </table>
                        </div> 
                      </div> -->
                     
                    </div>
                </div> 
                    </div>
                  </div>
                      
            </div>
            <div class="modal-footer">
                
            </div>
        
        </div>
    </div>
<!-- </div> -->


