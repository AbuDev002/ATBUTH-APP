<!-- Modal -->
<div class="modal take-report-modal animate__animated animate__zoomIn" id="EditClinictModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">EDIT CLINIC</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                              
                 <form id="Clinic">
                     <input type="hidden" id="clinicid_edit" class="clinicid_edit">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-4 offset-md-4">

                    <fieldset class="scheduler-border">
                        <legend class="scheduler-border">Clinic Details</legend>
                         <div class="form-group">
                            <label>Clinic Name</label>
                            <input type="text" name="clinic_name" id="clinic_name" class="form-control clinic_name">
                        </div>
                        <div class="form-group">
                        	<button type="button" class="btn btn-primary" id="UpdateClinic">Update Clinic</button>
                        </div>
                    </fieldset>

                    </div>
                    
                    </div>
                </div> 
            </div>
                         
            </div>
           
         </div>
        </form>
        </div>
    </div>
</div>

