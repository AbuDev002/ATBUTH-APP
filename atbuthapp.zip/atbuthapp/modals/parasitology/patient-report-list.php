<!-- Modal -->
<div class="modal fade animate__animated animate__zoomIn" id="ParasitologyPatientReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Patient Reports</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      
        <table class="table table-bordered table-responsive w-100 d-block d-md-table" style="font-size: 12px;">
          <thead>
            <tr>
              <th>S/N</th>
              <th>Reciept No.</th>
              <th>Date of Capture</th>
              <th>Time of Capture</th>
              <th>Spaciment</th>
              <th>Investigation</th>
              <th>Date</th>
              <th>Report</th>
            </tr>
          </thead>
          <tbody id="displayParasitologyReportList">
            
          </tbody>
        </table>
      </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>
</div>