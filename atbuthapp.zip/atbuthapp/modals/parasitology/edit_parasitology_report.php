<!-- Modal -->
<div class="modal take-report-modal animate__animated animate__zoomIn" id="EditParasitologyReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">PARASITOLOGY REPORT FORM</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-4 offset-md-4">
                    <form id="ParasitologyReportForm">
                        <input type="hidden" id="parasitid_edit" class="parasitid_edit">
                       
                    <div class="form-group">
              <input type="hidden" name="np" id="np" value="">
            </div>
                    <div class="form-group">
                        <label for="">Investigation</label>
                       <select name="investigation" id="invest" class="form-control selectpicker investigation" data-live-search="true">
                            <option>--Investigation--</option>
                           <?php 
                                include_once('connection.php');
                                $get_all_analysis = mysqli_query($conms,"select * from tbl_general");
                                while($analysis_list = mysqli_fetch_array($get_all_analysis)){
                                        $analysis_id = $analysis_list['id'];
                                        $analysis_name = $analysis_list['item_name'];
                                        
                                if (@$_POST['investigation'] == $analysis_id) {

                                    echo "<option value=\"".$analysis_id."\" selected='selected'>".$analysis_name." </option>"; 
                                    } else {
                                        echo "<option value=\"".$analysis_id."\">".$analysis_name."</option>";       
                                    }
                                }   
                                ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Date of Sample Collection</label>
                        <input type="date" name="date_sample_collect" id="date_sample_collect" class="form-control date_sample_collect" autocomplete="off" placeholder="Date of Sample Collection...">
                    </div>
                    <div class="form-group">
                            <label for="">Time of Sample Collection</label>
                            <input type="time" name="time_sample_collect" id="time_sample_collect" class="form-control time_sample_collect" autocomplete="off" placeholder="Time of Sample Collection">
                    </div>

                    <div class="form-group">
                        <label for="">Reciept</label>
                        <input type="text" name="receipt_no" id="receipt_no" class="form-control receipt_no" autocomplete="off" placeholder="Receipt No...">
                    </div>

                     <div class="form-group">
                        <label for="">Clinical Diagnosis</label>
                        <input type="text" name="clinical_diagnosis" id="clinical_diagnosis" class="form-control clinical_diagnosis" autocomplete="off" placeholder="Clinical Diagnosis...">
                    </div>

                    <div class="form-group">
                       <label for="">Laboratory Result</label>
                       <textarea name="lab_comment" id="lab_comment" class="form-control lab_comment" cols="30" rows="5" placeholder="Type Laboratory Result..."></textarea>
                    </div>
                    <div class="form-group">
                        <label for="">Spacemen</label>
                        <select name="spacemen" id="spacemen" class="form-control spacemen">
                            <option value="">--Spacemen--</option>
                            <option value="Blood">Blood</option>
                            <option value="Stool">Stool</option>
                            <option value="Urine">Urine</option>
                            <option value="CSF">CSF</option>
                            <option value="Skin/Tissue">Skin/Tissue</option>
                            <option value="Sputum">Sputum</option>
                            <option value="Aspirate">Aspirate</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                    
                    <p><button type="submit" class="btn btn-primary ladda-button" data-style="expand-right" data-size="s" id="btnSaveParasitPatientResult">Save</button></p>
                    </form>
                    </div>
                    <!-- <div class="col-md-8">
                        

                    </div> -->
                     
                    </div>
                </div> 
                    </div>
                  </div>
                      
            </div>
            <div class="modal-footer">
          
            </div>
        
        </div>
    </div>
<!-- </div> -->

