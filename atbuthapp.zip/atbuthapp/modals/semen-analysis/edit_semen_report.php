<!-- Modal -->
<div class="modal take-report-modal animate__animated animate__zoomIn" id="EditSemenAnalysisReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">EDIT SEMEN ANALYSIS REPORT</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                              
                 <form id="SemenReportForm">
                     <input type="hidden" id="semenid_edit" class="semenid_edit">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-4">

                    <fieldset class="scheduler-border">
                        <legend class="scheduler-border">Seminal Fluid Analysis</legend>
                         <div class="form-group">
                            <label>Date Produce</label>
                            <input type="date" name="date_produce" id="date_produce" class="form-control date_produce">
                        </div>
                        <div class="form-group">
                            <label>Time Produce</label>
                            <input type="time" name="time_produce" id="time_produce" class="form-control time_produce">
                        </div>
                        <div class="form-group">
                            <label>Time Recieved</label>
                            <input type="time" name="time_recieve" id="time_recieve" class="form-control time_recieve">
                        </div>
                        <div class="form-group">
                            <label>Time Examined</label>
                            <input type="time" name="time_examined" id="time_examined" class="form-control time_examined">
                        </div>
                       <div class="form-group">
                               <label>Volume</label>
                               <input type="text" name="volume" id="volume" class="form-control volume">
                           </div>
                    </fieldset>

                    </div>
                    <div class="col-md-4">
                       <fieldset class="scheduler-border">
                           <legend class="scheduler-border">Macroscopy</legend>
                           <div class="form-group">
                               <label>Appearance</label>
                               <input type="text" name="appearance" id="appearance" class="form-control appearance">
                           </div>
                           <div class="form-group">
                               <label>Consistency</label>
                               <input type="text" name="consistency" id="consistency" class="form-control consistency">
                           </div>
                           <div class="form-group">
                               <label>Liquifaction</label>
                               <input type="text" name="liquifaction" id="liquifaction" class="form-control liquifaction">
                           </div>
                           <div class="form-group">
                               <label>PH</label>
                               <input type="text" name="ph" id="ph" class="form-control ph">
                           </div>
                          
                       </fieldset>
                      </div>
                      <div class="col-md-4">
                        <fieldset class="scheduler-border">
                           <legend class="scheduler-border">All Sperm</legend>
                           <div class="form-group">
                               <label>Concentration mm<sup>2</sup></label>
                               <input type="text" name="concentration" id="concentration" class="form-control concentration">
                           </div>
                           <div class="form-group">
                               <label>MSC</label>
                               <input type="text" name="msc" id="msc" class="form-control msc">
                           </div>
                           <div class="form-group">
                               <label>FSC</label>
                               <input type="text" name="fsc" id="fsc" class="form-control fsc">
                           </div>
                           <div class="form-group">
                               <label>SMI</label>
                               <input type="text" name="smi" id="smi" class="form-control smi">
                           </div>
                           <div class="form-group">
                                    <button class="btn btn-primary ladda-button" data-style="expand-right" data-size="s" data-color="#000" id="btnSaveSemenPatientResult">Save Report</button>
                            </div>
                        </fieldset>
                      </div>
                    </div>
                </div> 
            </div>
                         
            </div>
           
         </div>
        </form>
        </div>
    </div>
</div>

