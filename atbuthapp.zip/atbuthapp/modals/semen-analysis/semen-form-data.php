<!-- Modal -->
<div class="modal take-report-modal animate__animated animate__zoomIn" id="TakeSemenAnalysisReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">SEMEN ANALYSIS REPORT FORM</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">APPLICANT DETAILS</h5></center> -->
               
                 <form id="SemenReportForm">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-4">
                   
                        <!-- <label for="">Patient Name</label> -->
                        <!-- <div class="form-group">
						  <input type="hidden" name="pn" id="pn" value="">
					    </div> -->

                    <fieldset class="scheduler-border">
                        <legend class="scheduler-border">Seminal Fluid Analysis</legend>
                         <div class="form-group">
                            <label>Date Produce</label>
                            <input type="date" name="date_produce" id="date_produce" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Time Produce</label>
                            <input type="time" name="time_produce" id="time_produce" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Time Recieved</label>
                            <input type="time" name="time_recieve" id="time_recieve" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Time Examined</label>
                            <input type="time" name="time_examined" id="time_examined" class="form-control">
                        </div>
                       <div class="form-group">
                               <label>Volume</label>
                               <input type="text" name="volume" id="volume" class="form-control">
                           </div>
                    </fieldset>

                    </div>
                    <div class="col-md-4">
                       <fieldset class="scheduler-border">
                           <legend class="scheduler-border">Macroscopy</legend>
                           <div class="form-group">
                               <label>Appearance</label>
                               <input type="text" name="appearance" id="appearance" class="form-control">
                           </div>
                           <div class="form-group">
                               <label>Consistency</label>
                               <input type="text" name="consistency" id="consistency" class="form-control">
                           </div>
                           <div class="form-group">
                               <label>Liquifaction</label>
                               <input type="text" name="liquifaction" id="liquifaction" class="form-control">
                           </div>
                           <div class="form-group">
                               <label>PH</label>
                               <input type="text" name="ph" id="ph" class="form-control">
                           </div>
                          
                       </fieldset>
                      </div>
                      <div class="col-md-4">
                        <fieldset class="scheduler-border">
                           <legend class="scheduler-border">All Sperm</legend>
                           <div class="form-group">
                               <label>Concentration mm<sup>2</sup></label>
                               <input type="text" name="concentration" id="concentration" class="form-control">
                           </div>
                           <div class="form-group">
                               <label>MSC</label>
                               <input type="text" name="msc" id="msc" class="form-control">
                           </div>
                           <div class="form-group">
                               <label>FSC</label>
                               <input type="text" name="fsc" id="fsc" class="form-control">
                           </div>
                           <div class="form-group">
                               <label>SMI</label>
                               <input type="text" name="smi" id="smi" class="form-control">
                           </div>
                           <div class="form-group">
                                    <button class="btn btn-primary ladda-button" data-style="expand-right" data-size="s" data-color="#000">Save Report</button>
                            </div>
                        </fieldset>
                      </div>
                    </div>
                </div> 
            </div>
                         
            </div>
            <!-- <div class="modal-footer">
                
            </div> -->
         </div>
        </form>
        </div>
    </div>
</div>

