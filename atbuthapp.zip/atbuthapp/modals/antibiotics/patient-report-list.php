<!-- Modal -->
<div class="modal hide fade animate__animated animate__zoomIn" id="SensitivityPatientReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-width="760">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Patient Reports</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="message-show"></div>
        <table class="table table-bordered table-responsive w-100 d-block d-md-table" style="font-size: 12px;">
          <thead>
            <tr>
              <th>S/N</th>
              <th>Investigation</th>
              <th>Appearace Microscopy</th>
              <th>Micro Serology</th>
              <th>Culture Yelded</th>
              <th>Date Recieved</th>
              <th>Date Issued</th>
              <th>Report</th>
            </tr>
          </thead>
          <tbody id="displaySensitivityReportList">
            
          </tbody>
        </table>
      </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>
</div>
