<!-- Modal -->
<div class="modal hide fade take-report-modal animate__animated animate__zoomIn" id="EditSensitivityReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">SENSITIVITY REPORT FORM</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">APPLICANT DETAILS</h5></center> -->
               <div id="loader"></div>
       
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <!-- <div class="col-md-2">
                    
                  
                    </div> -->
                    <div class="col-md-8 offset-md-2"> 
                    <form id="SensitivityReportForm">
                    <input type="hidden" id="id_edit" class="id_edit">
                    <div class="form-group">
                         <input type="hidden" name="pn" id="pn" value="">
                    </div>
                    <div class="form-group">
                        <label>TYPE OF REQUEST/SPACEMEN/INVESTIGATION</label>
                        <select name="request_type" id="request_type" class="form-control selectpicker request_type" data-live-search="true">
                            <option value="">the type of request</option>
                           <?php 
                                include_once('connection.php');
                                $get_all_analysis = mysqli_query($conms,"select * from tbl_general");
                                while($analysis_list = mysqli_fetch_array($get_all_analysis)){
                                        $analysis_id = $analysis_list['id'];
                                        $analysis_name = $analysis_list['item_name'];
                                        
                                if (@$_GET['antibiotic'] == $analysis_id) {

                                    echo "<option value=\"".$analysis_id."\" selected='selected'>".$analysis_name." </option>"; 
                                    } else {
                                        echo "<option value=\"".$analysis_id."\">".$analysis_name."</option>";       
                                    }
                                }   
                                ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>APPEARACE/MICROSCOPY</label>
                        <input type="text" name="appearace_microscopy" id="appearace_microscopy" class="form-control appearace_microscopy">
                    </div>
                    <div class="form-group">
                        <label>MICROLOGY/SEROLOGY REPORT</label>
                        <textarea cols="10" rows="5" name="ms_report" id="ms_report" class="form-control pclu-textarea ms_report"></textarea>
                        
                    </div>
                    <div class="form-group">
                        <label>CULTURE YIELDED</label>
                        <input type="text" name="culture_yield" id="culture_yield" class="form-control culture_yield">
                    </div>
                    <div class="form-group">
                        <label>DATE RECIEVED</label>
                        <input type="date" name="date_recieved" id="date_recieved" class="form-control date_recieved">
                    </div>
                    <div class="form-group">
                        <label>DATE ISSUED</label>
                        <input type="date" name="date_issued" id="date_issued" class="form-control date_issued">

                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary ladda-button" data-style="expand-right" data-size="s" data-color="#000" id="btnSaveSensPatientResult">Save Result</button>
                    </div>
                    </form>
                    </div>
                    <!-- <div class="col-md-4">
                        
                       
                    </div> -->
                     
                    </div>
                </div> 
                    </div>
                  </div>
                      
            </div>
            <div class="modal-footer">
                <!-- <input type="hidden" name="member_id" id="member_id" /> 
                <input type="submit" value="Save Member" name="btnAddMember" id="btnAddMember" class="btn btn-primary btn-block">
             -->
            </div>
        
        </div>
    </div>
<!-- </div> -->


