<?php
include_once("../../connection.php");
if($_GET['q']) {
	$sql = "SELECT * FROM patient_antibiotic_report WHERE patient_id='".$_GET['q']."'";
	$resultset = mysqli_query($conms, $sql) or die("database error:". mysqli_error($conms));
	
	$data = array();
	while($rows = mysqli_fetch_assoc($resultset) ) {
		//$data = $rows;
        
    ?>
<tr>
    <td>
        <?php 
            $getAntibiotic = mysqli_query($conms,"select * from antibiotics WHERE id =".$rows['antibiotic_id']."");
            $antibioticName = mysqli_fetch_array($getAntibiotic);
            echo $antibioticName['antibiotic_name'];
        ?>
    </td>
    <td><?php echo $rows['test1']; ?></td>
    <td><?php echo $rows['test2']; ?></td>
    <td><?php echo $rows['test3']; ?></td>
    <td>
    <!-- <a href="#" class="btn btn-danger delete_report"><i class="fa fa-trash"></i></a> -->
    <button class="btn btn-danger delete_report" id="<?php echo $rows['id'];?>"><span class="badge badge-danger badge-pill"><i class="fa fa-trash"></i></span></button>
    </td>
</tr>

<?php } } ?>