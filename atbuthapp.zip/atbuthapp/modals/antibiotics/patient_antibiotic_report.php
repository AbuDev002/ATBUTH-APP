<!-- Modal -->
<div class="modal hide fade take-report-modal animate__animated animate__zoomIn" id="TakeSensitivityReportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">SENSITIVITY REPORT FORM</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <!--  <center><h5 class="card-title">APPLICANT DETAILS</h5></center> -->
               <div id="loader"></div>
       
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-4">
                    <form id="addTakeReportForm" action="">
                        <input type="hidden" name="patient_name" id="patient_name" value="">
                        <!-- <label for="">Patient Name</label>
                        <div class="form-group">
						<select  name="patient_name" id="patient_name" class="form-control selectpicker" data-live-search="true">
							<option>--Select Patient--</option>
							<?php 
								// include_once('connection.php');
								// $get_patient = mysqli_query($conms,"select * from patients");
								// while($patient_list = mysqli_fetch_array($get_patient)){
								// 		$patient_id = $patient_list['id'];
								// 		$patient_surname = $patient_list['surname'];
								// 		$patient_firstname = $patient_list['firstname'];
								// 		$patient_othername = $patient_list['othername'];
									
								?>
                                <option value="<?php //echo $patient_id; ?>"><?php //echo $patient_surname.''.$patient_firstname.' '.$patient_othername;?></option> 
                            <?php //} ?>
						</select>
					</div> -->

                       <label>Antibiotic</label>
                       <div class="form-group">
						<select name="antibiotic_name" id="antibiotic_name" class="form-control selectpicker" data-live-search="true">
							<option value="">--Antibiotic--</option>
							<?php 
								include_once('connection.php');
								$get_antibiotics = mysqli_query($conms,"select * from antibiotics");
								while($antibiotic_list = mysqli_fetch_array($get_antibiotics)){
										$antibiotic_id = $antibiotic_list['id'];
										$antibiotic_name = $antibiotic_list['antibiotic_name'];
										
								if (@$_GET['antibiotic'] == $antibiotic_id) {

									echo "<option value=\"".$antibiotic_id."\" selected='selected'>".$antibiotic_name." </option>"; 
									} else {
										echo "<option value=\"".$antibiotic_id."\">".$antibiotic_name."</option>";       
									}
								}	
								?>
						</select>
                    </div>
                    <label>Result</label>
                    <div class="form-group">
						<select name="test_result" id="test_result" class="form-control">
							<option value="">--Result--</option>
							<option value="S">Senstive (S)</option>
							<option value="R">Resistance (R)</option>
							<option value="I">Intermediate (I)</option>
						</select>
					</div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary ladda-button" data-style="expand-right" data-size="s" data-color="#000" id="btnAddTakeReport">Add Test Result</button>
                    </div>
                    </form>
                    <hr>
                    <div class="" style="height:450px;width:100%;overflow:auto;">
                        
                       
                         <table class="table table-bordered">
                          <thead>
                          <tr>
                                <th colspan="4">RECORD SENSITIVITY TEST</th>
                            </tr>
                            <tr>
                                <td><strong>Antibiotic</strong></td>
                                <td><strong>1</strong></td>
                                <td><strong>2</strong></td>
                                <td><strong>3</strong></td>
                            </tr>
                          </thead>
                          <tbody id="records">
                                
                          </tbody>

                          <!--  <tfoot id="no_records">
                                <tr>
                                    <td colspan="4"><strong>No record available</strong></td>
                                </tr>
                          </tfoot>   -->
                         </table>
                          </div> 
                    </div> 
                    <div class="col-md-8"> 
                    <form id="SensitivityReportForm">
                    <div class="form-group">
                         <input type="hidden" name="pn" id="pn" value="">
                    </div>
                    <div class="form-group">
                        <label>TYPE OF REQUEST/SPACEMEN/INVESTIGATION</label>
                        <select name="request_type" id="request_type" class="form-control selectpicker" data-live-search="true">
                            <option value="">--Type of Request</option>
                           <?php 
                                include_once('connection.php');
                                $get_all_analysis = mysqli_query($conms,"select * from tbl_general");
                                while($analysis_list = mysqli_fetch_array($get_all_analysis)){
                                        $analysis_id = $analysis_list['id'];
                                        $analysis_name = $analysis_list['item_name'];
                                        
                                if (@$_GET['antibiotic'] == $analysis_id) {

                                    echo "<option value=\"".$analysis_id."\" selected='selected'>".$analysis_name." </option>"; 
                                    } else {
                                        echo "<option value=\"".$analysis_id."\">".$analysis_name."</option>";       
                                    }
                                }   
                                ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>APPEARACE/MICROSCOPY</label>
                        <input type="text" name="appearace_microscopy" id="appearace_microscopy" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>MICROLOGY/SEROLOGY REPORT</label>
                        <textarea cols="10" rows="5" name="ms_report" id="ms_report" class="form-control pclu-textarea"></textarea>
                        
                    </div>
                    <div class="form-group">
                        <label>CULTURE YIELDED</label>
                        <input type="text" name="culture_yield" id="culture_yield" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>DATE RECIEVED</label>
                        <input type="date" name="date_recieved" id="date_recieved" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>DATE ISSUED</label>
                        <input type="date" name="date_issued" id="date_issued" class="form-control">

                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary ladda-button" data-style="expand-right" data-size="s" data-color="#000" id="btnSaveResult">Save Result</button>
                    </div>
                    </form>
                    </div>
                    <!-- <div class="col-md-4">
                        
                       
                    </div> -->
                     
                    </div>
                </div> 
                    </div>
                  </div>
                      
            </div>
            <div class="modal-footer">
                <!-- <input type="hidden" name="member_id" id="member_id" /> 
                <input type="submit" value="Save Member" name="btnAddMember" id="btnAddMember" class="btn btn-primary btn-block">
             -->
            </div>
        
        </div>
    </div>
<!-- </div> -->


