<!-- Modal -->
<div class="modal take-report-modal animate__animated animate__zoomIn" id="EditSpacimentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">EDIT SPACIMEN</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                              
                 <form id="Spacimen">
                     <input type="hidden" id="spacimenid_edit" class="spacimenid_edit">
                  <div class="card">
                    <div class="card-body">
                        <div class="row">
                    <div class="col-md-4 offset-md-4">

                    <fieldset class="scheduler-border">
                        <legend class="scheduler-border">Spacimen Details</legend>
                         <div class="form-group">
                            <label>Spacimen Name</label>
                            <input type="text" name="spacimen_name" id="spacimen_name" class="form-control spacimen_name">
                        </div>
                        <div class="form-group">
                        	<button type="button" class="btn btn-primary" id="UpdateSpacimen">Update Spacimen</button>
                        </div>
                    </fieldset>

                    </div>
                    
                    </div>
                </div> 
            </div>
                         
            </div>
           
         </div>
        </form>
        </div>
    </div>
</div>

