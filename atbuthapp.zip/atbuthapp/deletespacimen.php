<?php
include_once('connection.php');
if(isset($_GET['deletespacimen'])) {
$deltid = $_GET['deletespacimen']; 
$usertDetails = mysqli_query($conms,"DELETE FROM tbl_spacimens WHERE id=".$deltid."");
header('location:spacimens.php');
}else{
    header('location:spacimens.php');
}
?>