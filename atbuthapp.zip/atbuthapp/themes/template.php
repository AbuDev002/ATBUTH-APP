<?php
session_start();
//error_reporting(0);
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
	<div  class="container">
		<?php include_once('incs/upnavbar.php');?>
		<div class="row" style="background: #f5f5f5;">
			<?php include_once('incs/sidemenu.php');?>
			 <div class="col-sm-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
			 		<?php require_once $content;?>
			</div>
		
</div>
<?php include_once('incs/copyright.php');?>
<?php include('incs/footer.php');?>
