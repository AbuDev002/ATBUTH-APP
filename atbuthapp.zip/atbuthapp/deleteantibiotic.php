<?php
include_once('connection.php');
if(isset($_GET["deleteantibiotic"]))
{
$del_id = $_GET["deleteantibiotic"];
 $query = "DELETE FROM antibiotics WHERE id = '".$del_id."'";
 if(mysqli_query($conms, $query))
 {
    header('location:antibiotics.php');
 }
}else{
    header('location:antibiotics.php');
}
?>