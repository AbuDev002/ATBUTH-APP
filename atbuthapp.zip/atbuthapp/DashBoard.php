
       			<div class="container">
			<?php
				@$id=$_SESSION['userid'];
				$content='default_content.php';
				$chk = (isset($_REQUEST['chk']) && $_REQUEST['chk'] != '') ? $_REQUEST['chk'] : '';
				switch ($chk) {
					case 'vprofile' :
				        $title="Profile Page";	
						$content='profile_page.php';		
						break;
					case 'patients-report' :
					    $title="Patients Report";	
						$content ='patients-report.php';
						break;
					default :
					    $title="Home";	
						$content ='default_content.php';		
				}
			?>
    		</div>
<?php require_once 'themes/template.php';?>

    <script type="text/javascript">
  $('.from').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
    startView: 2,
    minView: 2,
    forceParse: 0
    });
  $('.to').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
    startView: 2,
    minView: 2,
    forceParse: 0
    });
    $(function() {
    var dates = $( "#from, #to" ).datepicker({                   
      defaultDate:'',
      changeMonth: true,
      numberOfMonths: 1,
      onSelect: function( selectedDate ) {
      var now =Date();
        var option = this.id == "from" ? "minDate" : "maxDate",
          instance = $(this).data("datepicker"),
          date = $.datepicker.parseDate(
            instance.settings.dateFormat ||
            $.datepicker._defaults.dateFormat,
            selectedDate, instance.settings );
        dates.not( this ).datepicker( "option", option, date );
      }
    });
  });
</script>