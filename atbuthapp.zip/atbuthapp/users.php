<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Users";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<form action="" method="post" enctype="multipart/form-data">
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					 <a href="add_user.php" class="btn btn-primary margin-bottom"><i class="fa fa-plus"></i> Add New Staff</a>
					 <hr/>
					 <table class="table table-bordered table-responsive table-striped table-hover custom_table">
					 	<thead>
					 	<tr>
					 		<th>#StaffID</th>
					 		<th>Name</th>
					 		<th>Username</th>
					 		<th>Email</th>
					 		<th>Last Login</th>
					 		<th></th>
					 		<th></th>
					 	</tr>
					 	</thead>
					 	<tbody>
					 	<?php 
					 		$count = 0;
					 		if($_SESSION['account_type'] == 'Superadmin'){
					 			include_once('connection.php');
					 			$getusers_sql = mysqli_query($conms,"select * from userinfo");
					 			while($rows_rs = mysqli_fetch_array($getusers_sql)){
					 			$count++;
					 			
							 	?>
							 	<tr>
							 		<td><?php echo $rows_rs['user_id'];?></td>
							 		<td><?php echo $rows_rs['name'];?></td>
							 		<td><?php echo $rows_rs['username'];?></td>
							 		<td><?php echo $rows_rs['email'];?></td>
							 		<td><?php echo $rows_rs['lastlogin'];?></td>
							 		<td><a onclick="return confirm('Are you sure to delete');" href="deleteuser.php?deleteuser=<?php echo $rows_rs['user_id'];?>"><i class="fa fa-trash"></i></a></td>
							 		<td>
							 		<?php if($rows_rs['account_staus']!=0){?>
										<a href="blockuser.php?bid=<?php echo $rows_rs['user_id']?>&act=0" class=""> <i class="fa fa-unlock"></i> UNBLOCK </a>
										<?php }else{?>
										<a href="blockuser.php?bid=<?php echo $rows_rs['user_id']?>&act=1"  class=""><i class="fa fa-lock"></i> BLOCK </a>
									<?php } ?>
							 				
							 		</td>
							
							 	</tr>
							<?php }} ?>
					 </tbody>
					 </table>
					</div>
						
				</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>