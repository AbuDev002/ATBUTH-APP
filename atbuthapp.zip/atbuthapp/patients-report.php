<div class="container">
<div class="card">
	<div class="card-header">Medical Microbiology Laboratory Report Form</div>
	<div class="card-body">
	<!-- begining of tab display -->
		<ul class="nav nav-tabs" id="myTab" role="tablist">
		  <li class="nav-item" role="presentation">
		    <a class="nav-link active" id="sensitivity-test-tab" data-toggle="tab" href="#sensitivity_test" role="tab" aria-controls="sensitivity_test" aria-selected="true">Sensitivity Test</a>
		  </li>
		  <li class="nav-item" role="presentation">
		    <a class="nav-link" id="serology-tab" data-toggle="tab" href="#serology" role="tab" aria-controls="serology" aria-selected="false">Serology</a>
		  </li>
		  <li class="nav-item" role="presentation">
		    <a class="nav-link" id="semen-analysis-tab" data-toggle="tab" href="#semen_analysis" role="tab" aria-controls="semen_analysis" aria-selected="false">Semen Analysis</a>
		  </li>
		  <li class="nav-item" role="presentation">
		    <a class="nav-link" id="parasitology-tab" data-toggle="tab" href="#parasitology" role="tab" aria-controls="parasitology" aria-selected="false">Parasitology</a>
		  </li>
		</ul>
	<!-- ending of tab display -->
	<br>
	<div class="tab-content" id="myTabContent">
	  <div class="tab-pane animate__animated animate__zoomIn show active" id="sensitivity_test" role="tabpanel" aria-labelledby="sensitivity-test-tab">
	  		<form id="addReportForm" name="addReportForm">
		<div class="row">
			
			
			<div class="col-md-12" style="overflow:auto;">
			<fieldset class="scheduler-border">
					<legend class="scheduler-border"><strong>Record Sensitivity Test Result</strong></legend>
					<div class="" style="height:340px;width:100%;overflow:auto;">
						<p><input type="text" name="search_patient" id="search_patient" class="form-control" placeholder="Search patient..."></p>
						<table class="table table-bordered">
								<thead>
								<tr>
									<th>S/N</th>
									<th>Name</th>
									<th>Record Report</th>
									<th>Print Report</th>
									<th>View Result</th>
								</tr>
								</thead>
								<tbody id="tbl_SensitivityReportList">
								
								</tbody>
								
						</table>
					</div>
					
			</fieldset>
			</div>
		</div>
		
		
</form>
</div>
	  <div class="tab-pane animate__animated animate__zoomIn" id="serology" role="tabpanel" aria-labelledby="serology-tab">
	  		<form id="addSerologyForm" name="addSerologyForm">
		<div class="row">
			
			<div class="col-md-12" style="overflow:auto;">
			<fieldset class="scheduler-border">
					<legend class="scheduler-border"><strong>Record Serology Result</strong></legend>
					<div class="" style="height:340px;width:100%;overflow:auto;">
						<p><input type="text" name="search_seropatient" id="search_seropatient" class="form-control" placeholder="Search patient..."></p>
						<table class="table table-bordered">
								<thead>
								<tr>
									<th>S/N</th>
									<th>Name</th>
									<th>Date</th>
									<th></th>
									<th></th>
								</tr>
								</thead>
								<tbody id="tbl_SerologyReportList">
								
								</tbody>
								
						</table>
					</div>
					
			</fieldset>
			</div>
		</div>
		
		
</form>
	  </div>
	  <div class="tab-pane animate__animated animate__zoomIn" id="semen_analysis" role="tabpanel" aria-labelledby="semen-analysis-tab">
	  	<form id="addSemenAnalysisForm" name="addSemenAnalysisForm">
		<div class="row">
			
			<div class="col-md-12" style="overflow:auto;">
			<fieldset class="scheduler-border">
					<legend class="scheduler-border"><strong>Record Semen Aanalysis Result</strong></legend>
					<div class="" style="height:340px;width:100%;overflow:auto;">
						<p><input type="text" name="search_semenpatient" id="search_semenpatient" class="form-control" placeholder="Search patient..."></p>
						<table class="table table-bordered">
								<thead>
								<tr>
									<th>S/N</th>
									<th>Name</th>
									<th>Date</th>
									<th></th>
									<th></th>
								</tr>
								</thead>
								<tbody id="tbl_SemenAnalysisList">
								 	
								</tbody>
								
						</table>
					</div>
					
			</fieldset>
			</div>
		</div>
		
		
</form>
	  </div>
	  <div class="tab-pane animate__animated animate__zoomIn" id="parasitology" role="tabpanel" aria-labelledby="parasitology-tab">
	  	<form id="addParasitologyForm" name="addParasitologyForm">
		<div class="row">
			<div class="col-md-12" style="overflow:auto;">
			<fieldset class="scheduler-border">
					<legend class="scheduler-border"><strong>Record Parasitology Result</strong></legend>
					<div class="" style="height:340px;width:100%;overflow:auto;">
						<p><input type="text" name="search_parapatient" id="search_parapatient" class="form-control" placeholder="Search patient..."></p>
						<table class="table table-bordered">
								<thead>
								<tr>
									<th>S/N</th>
									<th>Name</th>
									<th>Date</th>
									<th></th>
									<th></th>
								</tr>
								</thead>
								<tbody id="tbl_ParasitolotyList">

								</tbody>
								
						</table>
					</div>
					
			</fieldset>
			</div>
		</div>
		
		
</form>
	  </div>
	</div>
	
	
	</div>
</div>
</div>
<?php include_once('modals/antibiotics/patient_antibiotic_report.php')?>
<?php include_once('modals/serology/serology-form-data.php')?>
<?php include_once('modals/semen-analysis/semen-form-data.php')?>
<?php include_once('modals/parasitology/parasitology-form-data.php')?>

<!--Report modals-->
<?php include_once('modals/parasitology/patient-report-list.php');?>
<?php include_once('modals/antibiotics/patient-report-list.php');?>
<?php include_once('modals/semen-analysis/patient-report-list.php');?>
<?php include_once('modals/serology/patient-report-list.php');?>

<!--Editing Modals-->
<?php include_once('modals/antibiotics/edit_antibiotic_report.php');?>
<?php include_once('modals/serology/edit_serology_report.php');?>
<?php include_once('modals/semen-analysis/edit_semen_report.php');?>
<?php include_once('modals/parasitology/edit_parasitology_report.php');?>
