 <?php  
 //fetch.php  
include_once('../../connection.php');  
$query = "SELECT * FROM tbl_patient_sensitivity_report WHERE patient_id='".$_GET['pid']."' ORDER BY id DESC";
$sn =0;  
$result = mysqli_query($conms, $query);
if($rs = mysqli_num_rows($result) >0){  
while($row = mysqli_fetch_array($result)) 
{
$sn++;
?>
 <tr>
      <td style="display: none;" class="patient_id"><?php echo $row['id'];?></td>
      <td><?php echo $sn;?></td>
      <td>
        <?php 
            $getInvest = mysqli_query($conms,"select * from tbl_general WHERE id =".$row['request_type']."");
              $investName = mysqli_fetch_array($getInvest);
            echo $investName['item_name'];
        ?>      
      </td>
      <td><?php echo $row['app_microscopy'];?></td>
      <td><?php echo $row['micro_serology'];?></td>
      <td><?php echo $row['culture_yeilded'];?></td>
      <td><?php echo $row['date_recieved'];?></td>
      <td><?php echo $row['date_issued'];?></td>
      <td>
          <a href="app/sensitivity-reports/report_result.php?pid=<?php echo $row['patient_id'];?>&rid=<?php echo $row['id'];?>" target="_blank">View Result</a>
     </td>
     <td><a href="#" class="sensEdit_btn"><i class="fa fa-edit" title="Edit"></i></a></td>
 </tr>
<?php 
} 
}else{
 echo "<tr><td colspan='8' align='center'>No report available</td></tr>";
}?>