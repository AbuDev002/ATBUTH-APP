<?php
 session_start();  
 include_once('../../connection.php');   
 if(isset($_POST['sensitive_report']))  
 {  
      $output = '';  
      $message = '';  
      $pn = mysqli_real_escape_string($conms, $_POST["pn"]);
      $request_type = mysqli_real_escape_string($conms, $_POST["request_type"]);
      $appearace_microscopy = mysqli_real_escape_string($conms, $_POST["appearace_microscopy"]);
      $ms_report = mysqli_real_escape_string($conms, $_POST["ms_report"]);
      $culture_yield = mysqli_real_escape_string($conms, $_POST["culture_yield"]);
      $date_recieved = mysqli_real_escape_string($conms, $_POST["date_recieved"]);
      $date_issued = mysqli_real_escape_string($conms, $_POST["date_issued"]);
      $query = "INSERT INTO tbl_patient_sensitivity_report (patient_id,request_type,app_microscopy,micro_serology,culture_yeilded,date_recieved,date_issued) VALUES ('$pn','$request_type','$appearace_microscopy','$ms_report','$culture_yield','$date_recieved','$date_issued')";    
      if(mysqli_query($conms,$query)){
		 $message = 'ok'; 
	  }else{
          echo $message = 'failed';
       }
 }  
 ?>