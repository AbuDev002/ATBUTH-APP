<?php
if(isset($_POST['checking_update'])){
	$id = $_POST['patient_id'];
	$request_type = $_POST['request_type'];
	$appearace_microscopy = $_POST['appearace_microscopy'];
	$ms_report = $_POST['ms_report'];
	$culture_yield = $_POST['culture_yield'];
	$date_recieved = $_POST['date_recieved'];
	$date_issued = $_POST['date_issued'];
	 include_once('../../connection.php');
	 $query ="UPDATE tbl_patient_sensitivity_report SET request_type='$request_type',app_microscopy='$appearace_microscopy', micro_serology='$ms_report', culture_yeilded='$culture_yield', date_recieved='$date_recieved',date_issued='$date_issued' WHERE id='$id'";
	 $query_run = mysqli_query($conms,$query);
	 if($query_run){
	 	echo $return = "Record successfully updated";
	 }else{
	 	echo $return ="Something Went Wrong";
	 }
}