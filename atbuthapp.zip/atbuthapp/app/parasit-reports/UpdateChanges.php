<?php
if(isset($_POST['checking_update'])){
	$id = $_POST['patient_id'];
	$investigation = $_POST['investigation'];
	$date_sample_collect = $_POST['date_sample_collect'];
	$time_sample_collect = $_POST['time_sample_collect'];
	$receipt_no = $_POST['receipt_no'];
	$clinical_diagnosis = $_POST['clinical_diagnosis'];
	$lab_comment = $_POST['lab_comment'];
	$spacemen = $_POST['spacemen'];
	
	
	 include_once('../../connection.php');
	 $query ="UPDATE tbl_patient_parasitology_report SET date_sample_collection='$date_sample_collect',time_sample_collection='$time_sample_collect',reciept_no='$reciept_no',clinical_diagnosis='$clinical_diagnosis',comment='$lab_comment',spacemen='$spacemen' WHERE id='$id'";
	 $query_run = mysqli_query($conms,$query);
	 if($query_run){
	 	echo $return = "Record successfully updated";
	 }else{
	 	echo $return ="Something Went Wrong";
	 }
}