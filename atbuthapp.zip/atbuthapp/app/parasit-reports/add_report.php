<?php
 session_start();  
 include_once('../../connection.php');   
 if(isset($_POST['parasit_report']))  
 {  
      $output = '';  
      $message = '';  
      $np = mysqli_real_escape_string($conms, $_POST["np"]);
      $date_sample_collect = mysqli_real_escape_string($conms, $_POST["date_sample_collect"]);
      $time_sample_collect = mysqli_real_escape_string($conms, $_POST["time_sample_collect"]);
      $clinical_diagnosis = mysqli_real_escape_string($conms, $_POST["clinical_diagnosis"]);
      $receipt_no = mysqli_real_escape_string($conms, $_POST["receipt_no"]);
      $lab_comment = mysqli_real_escape_string($conms, $_POST["lab_comment"]);
      $spacemen = mysqli_real_escape_string($conms, $_POST["spacemen"]);
      $investigation = mysqli_real_escape_string($conms, $_POST["investigation"]);
      $query = "INSERT INTO tbl_patient_parasitology_report (patient_id,date_sample_collection,time_sample_collection,reciept_no,clinical_diagnosis,comment,spacemen,investigation) VALUES ('$np','$date_sample_collect','$time_sample_collect','$receipt_no','$clinical_diagnosis','$lab_comment','$spacemen','$investigation')";    
      if(mysqli_query($conms,$query)){
		 $message = 'ok'; 
	  }else{
          echo $message = 'failed';
       }
 }  
 ?>