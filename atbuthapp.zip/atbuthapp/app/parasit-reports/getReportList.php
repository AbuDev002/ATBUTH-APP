 <?php  
 //fetch.php  
include_once('../../connection.php');  
$query = "SELECT * FROM tbl_patient_parasitology_report WHERE patient_id='".$_GET['pid']."' ORDER BY id DESC";
$sn =0;  
$result = mysqli_query($conms, $query);
if($rs = mysqli_num_rows($result) >0){  
while($row = mysqli_fetch_array($result)) 
{
$sn++;
?>
 <tr>
      <td style="display: none;" class="patient_id"><?php echo $row['id'];?></td>
      <td><?php echo $sn;?></td>
      <td><?php echo $row['reciept_no'];?></td>
      <td><?php echo $row['date_sample_collection'];?></td>
      <td><?php echo $row['time_sample_collection'];?></td>
      <td><?php echo $row['spacemen'];?></td>
      <td>
        <?php 
            $getInvest = mysqli_query($conms,"select * from tbl_general WHERE id =".$row['investigation']."");
            $investName = mysqli_fetch_array($getInvest);
            echo $investName['item_name'];
        ?>      
      </td>
      <td><?php echo $row['report_date'];?></td>
      <td>
          <a href="app/parasit-reports/report_result.php?pid=<?php echo $row['patient_id'];?>&rid=<?php echo $row['id'];?>">View Result</a>
     </td>
     <td><a href="#" class="parasitEdit_btn"><i class="fa fa-edit" title="Edit"></i></a></td>
 </tr>
<?php 
} 
}else{
 echo "<tr><td colspan='8' align='center'>No report available</td></tr>";
}?>