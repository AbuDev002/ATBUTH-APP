<?php
include_once('../connection.php');
$sn = 0;
$output = '';
if(isset($_POST["query"]))
{
  $search = mysqli_real_escape_string($conms, $_POST["query"]);
  $query = "
  SELECT * FROM patients 
  WHERE surname LIKE '%".$search."%'
  OR firstname LIKE '%".$search."%' 
  OR othername LIKE '%".$search."%' 
  ";
}
else
{
  $query = "SELECT * FROM patients ORDER BY id";
}
$result = mysqli_query($conms, $query);
if(mysqli_num_rows($result) > 0)
{
  
  while($getpatient_name = mysqli_fetch_array($result))
  {
    $sn++;
    $output .= '
      <tr>
        <td>'.$sn.'</td>
        <td>'.$getpatient_name["surname"].'</td>
        <td>'.$getpatient_name["firstname"].'</td>
        <td>'.$getpatient_name["othername"].'</td>
        <form>
        <input type="hidden" id="pid'.$sn.'" name="pid" class="pid" value="'.$getpatient_name["id"].'">
        <td><button type="button" class="btn btn-info btn-sm pReport" id="'.$getpatient_name['id'].'" data-toggle="modal" data-target="#TakeParasitologyReportModal" title="Take report"><i class="fa fa-file"></i></button></td>
        <td><a href="parasitology_report.php?pid='.$getpatient_name['id'].'" class="btn btn-info btn-sm" title="Print report"><i class="fa fa-print"></i></a></td>
        <td><button type="button" class="btn btn-info btn-sm btnParasitology" title="View Results" onclick="getReportList(\'pid'.$sn.'\')"><i class="fa fa-eye"></i></button></td>
        </form>
      </tr>
    ';
  }
  echo $output;
}
else
{
  echo '<tr><td align="center" colspan="5"><strong>No patient record available.</strong></td></tr>';
}
?>











