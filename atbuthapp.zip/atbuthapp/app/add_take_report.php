<?php
 session_start();  
 include_once('../connection.php');   
 if(isset($_POST['adding_report']))  
 {  
      $output = '';  
      $message = '';  
      $patient_name = mysqli_real_escape_string($conms, $_POST["patient_name"]);
      $antibiotic_name = mysqli_real_escape_string($conms, $_POST["antibiotic_name"]);
      $test_result = mysqli_real_escape_string($conms, $_POST["test_result"]);
      $query = "INSERT INTO patient_antibiotic_report (antibiotic_id,patient_id,test1) VALUES ('$antibiotic_name','$patient_name','$test_result')";    
      if(mysqli_query($conms,$query)){
		 $message = 'ok'; 
	  }else{
          echo $message = 'failed';
       }
 }  
 ?>