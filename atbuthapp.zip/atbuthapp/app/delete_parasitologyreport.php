<?php  
 //fetch.php  
include_once('../connection.php');  
 if(isset($_POST["prid"]))  
 {  
      $query = "DELETE FROM tbl_patient_parasitology_report WHERE id = ".$_POST["prid"]."";  
      $result = mysqli_query($conms, $query);  
      if($result){
      echo "ok";  
      }
 }  
 ?>