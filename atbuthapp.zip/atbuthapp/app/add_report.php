 <?php
 session_start();  
 include_once('../connection.php');   
 if(!empty($_POST))  
 {  
      $output = '';  
      $message = '';  
      $patient_name = mysqli_real_escape_string($conms, $_POST["patient_name"]);
      $clinic_ward = mysqli_real_escape_string($conms, $_POST["clinic_ward"]);
      $clinical_diagnosis = mysqli_real_escape_string($conms, $_POST["clinical_diagnosis"]);
      $spacemen = mysqli_real_escape_string($conms, $_POST["spacemen"]);
      $investigation_requested = mysqli_real_escape_string($conms, $_POST["investigation_requested"]);
      $report_date = mysqli_real_escape_string($conms, $_POST["report_date"]);
      $query = "INSERT INTO patients_lab_report (`patient_id`,`clinic_ward`,`clinical_diagnosis`,`spacemen`,`investigation_requested`,`report_date`) VALUES (".$patient_name.",'$clinic_ward','$clinical_diagnosis','$spacemen','$investigation_requested','$report_date')";    
      if(mysqli_query($conms,$query)){
		 $message = 'ok'; 
	  }
 }  
 ?>