<?php  
 //fetch.php  
include_once('../connection.php');  
 if(isset($_POST["patient_id"]))  
 {  
      $query = "DELETE FROM patient_antibiotic_report WHERE id = ".$_POST["patient_id"]."";  
      $result = mysqli_query($conms, $query);  
      if($result){
      echo "ok";  
      }
 }  
 ?>