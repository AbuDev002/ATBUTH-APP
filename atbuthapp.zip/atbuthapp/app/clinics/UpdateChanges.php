<?php
if(isset($_POST['checking_update'])){
	$id = $_POST['clinic_id'];
	$clinic_name = $_POST['clinic_name'];
	
	 include_once('../../connection.php');
	 $query ="UPDATE tbl_clinics SET clinic_name='$clinic_name' WHERE id='$id'";
	 $query_run = mysqli_query($conms,$query);
	 if($query_run){
	 	echo $return = "Record successfully updated";
	 }else{
	 	echo $return ="Something Went Wrong";
	 }
}