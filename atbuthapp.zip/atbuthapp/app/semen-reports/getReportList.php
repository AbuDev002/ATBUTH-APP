 <?php  
 //fetch.php  
include_once('../../connection.php');  
$query = "SELECT * FROM tbl_patient_semen_report WHERE patient_id='".$_GET['sem_id']."' ORDER BY id DESC";
$sn =0;  
$result = mysqli_query($conms, $query);
if($rs = mysqli_num_rows($result) > 0){  
while($row = mysqli_fetch_array($result)) 
{
$sn++;
?>
 <tr>
      <td style="display: none;" class="patient_id"><?php echo $row['id'];?></td>
      <td><?php echo $sn;?></td>
      <td><?php echo $row['time_produce'];?></td>
      <td><?php echo $row['time_recieve'];?></td>
      <td><?php echo $row['time_examine'];?></td>
      <td><?php echo $row['semen_volume'];?></td>
      <td><?php echo $row['report_date'];?></td>
      <td>
          <a href="app/semen-reports/report_result.php?pid=<?php echo $row['patient_id'];?>&rid=<?php echo $row['id'];?>" target="_blank">View Result</a>
     </td>
     <td><a href="#" class="semenEdit_btn"><i class="fa fa-edit" title="Edit"></i></a></td>
 </tr>
<?php 
} 
}else{
 echo "<tr><td colspan='8' align='center'>No report available</td></tr>";
}?>