<?php
if(isset($_POST['checking_update'])){
	$id = $_POST['patient_id'];
	$date_produce = $_POST['date_produce'];
	$time_produce = $_POST['time_produce'];
	$time_recieve = $_POST['time_recieve'];
	$time_examined = $_POST['time_examined'];
	$volume = $_POST['volume'];
	$appearance = $_POST['appearance'];
	$consistency = $_POST['consistency'];
	$liquifaction = $_POST['liquifaction'];
	$ph = $_POST['ph'];
	$concentration = $_POST['concentration'];
	$msc = $_POST['msc'];
	$fsc = $_POST['fsc'];
	$smi = $_POST['smi'];
	
	 include_once('../../connection.php');
	 $query ="UPDATE tbl_patient_semen_report SET date_produce='$date_produce',time_produce='$time_produce',time_recieve='$time_recieve',time_examine='$time_examined',semen_volume='$volume',appearance='$appearance',consistency='$consistency',liquifaction='$liquifaction',ph='$ph',concentration='$concentration',msc='$msc',fsc='$fsc',smi='$smi' WHERE id='$id'";
	 $query_run = mysqli_query($conms,$query);
	 if($query_run){
	 	echo $return = "Record successfully updated";
	 }else{
	 	echo $return ="Something Went Wrong";
	 }
}