<?php
 session_start();  
 include_once('../../connection.php');   
 if(isset($_POST['semen_report']))  
 {  
      $output = '';  
      $message = '';  
      $pn = mysqli_real_escape_string($conms, $_POST["pn"]);
      $date_produce = mysqli_real_escape_string($conms, $_POST["date_produce"]);
      $time_produce = mysqli_real_escape_string($conms, $_POST["time_produce"]);
      $time_recieve = mysqli_real_escape_string($conms, $_POST["time_recieve"]);
      $time_examined = mysqli_real_escape_string($conms, $_POST["time_examined"]);
      $volume = mysqli_real_escape_string($conms, $_POST["volume"]);
      $appearance = mysqli_real_escape_string($conms, $_POST["appearance"]);
      $consistency = mysqli_real_escape_string($conms, $_POST["consistency"]);
      $liquifaction = mysqli_real_escape_string($conms, $_POST["liquifaction"]);
      $ph = mysqli_real_escape_string($conms, $_POST["ph"]);
      $concentration = mysqli_real_escape_string($conms, $_POST["concentration"]);
      $msc = mysqli_real_escape_string($conms, $_POST["msc"]);
      $fsc = mysqli_real_escape_string($conms, $_POST["fsc"]);
      $smi = mysqli_real_escape_string($conms, $_POST["smi"]);
      $query = "INSERT INTO tbl_patient_semen_report (patient_id,date_produce,time_produce,time_recieve,time_examine,semen_volume,appearance,consistency,liquifaction,ph,concentration,msc,fsc,smi) VALUES ('$pn','$date_produce','$time_produce','$time_recieve','$time_examined','$volume','$appearance','$consistency','$liquifaction','$ph','$concentration','$msc','$fsc','$smi')";    
      if(mysqli_query($conms,$query)){
		 $message = 'ok'; 
	  }else{
          echo $message = 'failed';
       }
 }  
 ?>