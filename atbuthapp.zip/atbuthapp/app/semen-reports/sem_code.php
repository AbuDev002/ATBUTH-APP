 <?php  
 //fetch.php  
include_once('../../connection.php');  
 if(isset($_POST["sem_id"]))  
 {  
      $query = "SELECT * FROM patients WHERE id = '".$_POST["sem_id"]."'";   
      $result = mysqli_query($conms, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);  
 }  
 ?>