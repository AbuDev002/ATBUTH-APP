<?php
if(isset($_POST['checking_edit'])){
	$patient_id = $_POST['patient_id'];
	$result_array = [];
	include_once('../../connection.php');
	$query ="SELECT * FROM tbl_patient_serology_report WHERE id= '$patient_id'";
	$query_run = mysqli_query($conms, $query);

	if(mysqli_num_rows($query_run) > 0){
		foreach($query_run as $row){
			array_push($result_array, $row);
		}
		header('Content-type: application/json');
 		echo json_encode($result_array);
	}else{
		echo $return = "No Record Found";
	}
}