<?php
 session_start();  
 include_once('../../connection.php');   
 if(isset($_POST['serology_report']))  
 {  
      $output = '';  
      $message = '';  
      $pn = mysqli_real_escape_string($conms, $_POST["pn"]);
      $investigation = mysqli_real_escape_string($conms, $_POST["investigation"]);
      $invResult = mysqli_real_escape_string($conms, $_POST["invResult"]);
      $query = "INSERT INTO tbl_patient_serology_report (patient_id,investigation,result) VALUES ('$pn','$investigation','$invResult')";    
      if(mysqli_query($conms,$query)){
		 $message = 'ok'; 
	  }else{
          echo $message = 'failed';
       }
 }  
 ?>