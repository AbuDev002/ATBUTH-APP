<?php
if(isset($_POST['checking_update'])){
	$id = $_POST['patient_id'];
	$investigation = $_POST['investigation'];
	$invResult = $_POST['invResult'];
	
	 include_once('../../connection.php');
	 $query ="UPDATE tbl_patient_serology_report SET investigation='$investigation',result='$invResult' WHERE id='$id'";
	 $query_run = mysqli_query($conms,$query);
	 if($query_run){
	 	echo $return = "Record successfully updated";
	 }else{
	 	echo $return ="Something Went Wrong";
	 }
}