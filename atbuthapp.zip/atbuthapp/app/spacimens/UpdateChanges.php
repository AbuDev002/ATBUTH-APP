<?php
if(isset($_POST['checking_update'])){
	$id = $_POST['spacimen_id'];
	$spacimen_name = $_POST['spacimen_name'];
	
	 include_once('../../connection.php');
	 $query ="UPDATE tbl_spacimens SET spacimen_name='$spacimen_name' WHERE id='$id'";
	 $query_run = mysqli_query($conms,$query);
	 if($query_run){
	 	echo $return = "Record successfully updated";
	 }else{
	 	echo $return ="Something Went Wrong";
	 }
}