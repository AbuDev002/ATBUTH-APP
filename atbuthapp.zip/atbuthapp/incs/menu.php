<div role="navigation" class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          
        </div>
        <div class="navbar-collapse collapse">
         
        </div><!--/.nav-collapse -->
      </div>
</div>