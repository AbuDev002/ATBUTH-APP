<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>ATBUTH - Medical Microbiology Lab App <?php echo $title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="IMS  Mairasidi GLobal Resources">
    <meta name="author" content="Abubakar Ahmad Yusuf">
    <link rel="icon" type="image/jpg" sizes="100x100" href="images/fav.png">

    <!-- External styles -->
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css" />
    <link rel="stylesheet" href="css/jquery-ui.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <script src="https://kit.fontawesome.com/539625b579.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/datatable.min.css">
    <link href="css/font.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link rel="stylesheet" href="css/alertify.min.css" />
    <link rel="stylesheet" href="css/ladda.min.css" />
    <link rel="stylesheet" href="css/flashymodals.css" />
    <link rel="stylesheet" href="css/styles.css" />

    <script type="text/javascript">
        function deleteRow() {
            $('#inv_details').on('click', 'button[type="button"]', function () {
                $(this).closest('tr').remove();
            });
        }
    </script>
    <!-- <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
       <script>
      tinymce.init({
        selector: '#ms_report'
      });
  </script> -->
</head>
<body bgcolor="#dedede">
 <div id="preloader">
    <div data-loader="circle-side"></div>
</div>