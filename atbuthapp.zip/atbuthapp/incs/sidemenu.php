<div class="col-md-2 small-menu-users" id="left_side_menu" style="min-height: 500px;margin-top:10px;padding-top: 10px;">
<a href="DashBoard.php?chk=patients-report" class="btn btn-primary btn-block margin-bottom"><i class="fa fa-plus"></i> New Report </a>
 <aside class="list-group sm-side" style="border:1px solid silver;"> 
      <ul class="inbox-nav inbox-divider" style="margin-bottom: 0px;">
          <li class="active">
              <a href="DashBoard.php" class="list-group-item list-group-item-action"><i class="fa fa-home"></i> Dashboard </a>
               
          </li>
          <li>
                <a href="patients.php" class="list-group-item list-group-item-action"><i class="fa fa-users"></i> Patients </a>
          </li>
          <li>
                <a href="clinics.php" class="list-group-item list-group-item-action"><i class="fa fa-hospital"></i> Clinics </a>
          </li>
          <li>
                <a href="spacimens.php" class="list-group-item list-group-item-action"><i class="fa fa-hospital-o"></i> Spacimens </a>
          </li>
          <li>
                <a href="antibiotics.php" class="list-group-item list-group-item-action"><i class="fa fa-store"></i> Antibiotics</a>   
            </li>
          <li>
              <a href="profile_page.php" class="list-group-item list-group-item-action"><i class="fa fa-user-circle-o"></i> Profile </a>
          </li>
          <li>
              <a href="change_password.php" class="list-group-item list-group-item-action"><i class="fa fa-lock"></i> Change Password </a>   
          </li>
           <?php if($_SESSION['account_type'] =='Superadmin'){?>
            <li>
                <a href="access_logs.php" class="list-group-item list-group-item-action"><i class="fa fa-lock"></i> Access Logs </a>   
            </li>

             <li>
                <a href="users.php" class="list-group-item list-group-item-action"><i class="fa fa-users"></i> List of Users </a>   
            </li>
        
            <?php } ?>
          <li>
              <a href="logout.php" class="list-group-item list-group-item-action"><i class="fa fa-fw fa-power-off"></i> Logout</a>
          </li>
      </ul>
  </aside>
</div>