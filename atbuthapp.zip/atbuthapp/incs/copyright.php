<div class="text-center" style="color:#222; font-size:12px;margin-top:10px;margin-bottom: 10px;">Copyright &copy;
                                    <?php echo date('Y', time())?>
                                    ATBU Teaching Hospital - All right reserved.
                                            <br>Powered By <a href="https://brownwebappz.codes/" target="_blank" title="Developers" data-toggle="popover" data-trigger="hover" data-content="A product of Brown WebAppz" data-placement="bottom">Brown WebAppz</a></div>