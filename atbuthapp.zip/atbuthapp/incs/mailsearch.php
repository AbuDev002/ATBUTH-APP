 <div class="col-md-9">
<form>
  <div class="form-group">
    <input type="text" name="search_mail" id="search_mail" class="form-control" placeholder="Search mail...">
  </div>
</form>
</div>