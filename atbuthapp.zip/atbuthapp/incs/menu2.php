<div role="navigation" class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
         
        </div>
        <div class="navbar-collapse collapse">
         
        </div><!--/.nav-collapse -->
      </div>
      <h5> <i class="fas fa-hospital-user" style='font-size:48px;'></i> ATBUTH MedMicroLab-App</h5>
</div>
<div class="alert alert-info" style="background-color:#f5f5f5;border-color: silver;display: flex;justify-content:space-between;"><?php echo "<strong>Welcome ".$_SESSION['name']." ::: ".$_SESSION['email']."</strong>";?><a href="logout.php"><i class="fa fa-fw fa-power-off"></i> Logout</a></div>
<!-- <center><p class="text-warning">Your password will expire in 9 days</p></center> -->


