<span onclick="openNav()"><i class="togler-menu fa fa-align-justify fa-lg" ></i></span>
<div id="mySidenav" class="sidenav" style="background-color: #29166F !important;opacity: 0.9">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="DashBoard.php?chk=patients-report" class="btn btn-primary btn-block margin-bottom"><i class="fa fa-plus"></i>  Make Invoice</a>
  <a href="DashBoard.php" class="list-group-item list-group-item-action"><i class="fa fa-home"></i> Dashboard</a>
  <a  class="list-group-item list-group-item-action" href="patients.php"><i class="fa fa-users"></i> Patients</a> 
  <a href="profile_page.php" class="list-group-item list-group-item-action"><i class="fa fa-user-circle-o"></i> Profile </a>
  <a href="change_password.php" class="list-group-item list-group-item-action"><i class=" fa fa-lock"></i> Change Password </a>
  <?php if($_SESSION['account_type'] =='Superadmin'){?>
  <a  class="list-group-item list-group-item-action" href="access_logs.php"><i class=" fa fa-lock"></i> Access Logs</a>
  <a  class="list-group-item list-group-item-action" href="users.php"><i class="fa fa-users"></i> List of Users</a>
  <a href="stationstock.php" class="list-group-item list-group-item-action"><i class="fa fa-store"></i> Station Stock </a>
  
  <?php } ?>
   <a href="logout.php" class="list-group-item list-group-item-action"><i class=" fa fa-power-off"></i> Logout</a>
</div>