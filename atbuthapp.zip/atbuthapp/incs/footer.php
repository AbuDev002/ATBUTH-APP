
    <!-- <script src="js/jquery-1.10.2.min.js"></script> -->
    <!-- <script src="js/njquery.js"></script> -->
    <script src="js/jquery-3.5.1.js"></script>
    
    <script type="text/javascript" src="js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="js/icheck.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-datetimepicker.js"></script>
    <script src="js/bootstrap-datetimepicker.uk.js"></script>
    <script  src="js/jquery-ui.js" type="text/livescript"></script>
    <script src="js/script.js"></script>
   <script type="text/javascript" src="js/datatable.js" ></script>
   <script type="text/javascript" src="js/dataTables.bootstrap4.min.js" ></script>
  <script src="js/ckeditor/ckeditor.js"></script>
    <script>
        ClassicEditor
        .create( document.querySelector( 'textarea' ) )
        .catch( error => {
            console.error( error );
        } );
    </script>
   <script src="js/bootstrap-select.min.js"></script>
   <script src="js/alertify.min.js"></script>
   <script src="js/spin.min.js"></script> 
    <script src="js/ladda.min.js"></script>
    <script>

            // Bind normal buttons
            Ladda.bind( '.ladda-button', { timeout: 2000 } );

            // Bind progress buttons and simulate loading progress
            Ladda.bind( '.ladda-button', {
                callback: function( instance ) {
                    var progress = 0;
                    var interval = setInterval( function() {
                        progress = Math.min( progress + Math.random() * 0.1, 1 );
                        instance.setProgress( progress );

                        if( progress === 1 ) {
                            instance.stop();
                            clearInterval( interval );
                        }
                    }, 200 );
                }
            } );

        </script> 
   <script type="text/javascript">
  $(document).ready(function(){
    $('.selectpicker').selectpicker();
	
     $('.custom').DataTable( {
        responsive: true,
        "pageLength": 5,
        "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]]
    });
  });

</script>
    
    <script type="text/javascript">
        $(window).on('load',function(){

        // $('.loaders').on('click',fucntion(){
        /* ===========================
        ========== Pre-Loader ========
        ============================*/
        var preLoader = $("#preloader");
        preLoader.fadeOut(600);
        // });
        });
    </script>
     
    <!-- Userlogin  -->
    <script type="text/javascript">
    $(document).ready(function ($) {
        setTimeout(function(){
        $("#load").hide();
        $("#result").show();

        }, 2000);
        });
        $('document').ready(function($){
          //apply opacity to form
          function loadopacity(v){
              if(v == 'On'){
                $('#user-login').css({
                  opacity:0.2
                });
              
              }else{
                $('#user-login').css({
                  opacity:0.9
                });
              }

            }
            /* validation */
            $("#user-login").validate({
                rules:
                    {
                        password: {
                            required: true,
                        },
                        email: {
                            required: true,
                        },
                    },
                messages:
                    {
                        password: "<span style='color: red'>Password is required.</span>",
                        email: "<span style='color: red'>Email is required.</span>",
                    },
                submitHandler: submitForm
            });
            /* validation */

            /* login submit */
            function submitForm(){
                var data = $("#user-login").serialize();
                $.ajax({
                    type : 'POST',
                    url  : "checklogin.php",
                    data : data,
                    beforeSend: function()
                    {
                        loadopacity('On');
                        $("#error").fadeOut();
                        $("#working").html('<button class="btn btn-primary btn-block login" ><strong class="block" style="font-weight: bold;">  <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>  Verifying.... </strong></button>');
                    },
                    success :  function(response)
                    {
                        //loadopacity('On');
                        if(response=="User"){

                            $("#working").html('<button class="btn btn-primary btn-block login"> <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Success! redirecting...</button>');
                            setTimeout(' window.location.href = "DashBoard.php"; ',2000);
                        }else if(response=="Superadmin"){
                             $("#working").html('<button class="btn btn-primary btn-block login"> <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Success! redirecting...</button>');
                            setTimeout(' window.location.href = "DashBoard.php"; ',2000);
                        }else{
                           
                            $("#error").fadeIn(1000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                                $("#working").html('<button class="btn btn-primary btn-block login" id="working">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                 loadopacity('Off');
                            });
                             if(response=="Your password has expired."){
                            setTimeout(' window.location.href = "passwordexpired.php"; ',2000);
                        }

                        }
                    },
                    error :  function(response)
                    {
                        
                        $("#error").fadeIn(1000, function(){
                            $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                            $("#working").html('');
                           
                        });
                         //loadopacity('Off');
                    }

                });
                return false;
            }
            /* login submit */
        });
    </script>
    
    <script type="text/javascript">
            /* Open the sidenav */
            function openNav() {
              document.getElementById("mySidenav").style.width = "100%";
            }

            /* Close/hide the sidenav */
            function closeNav() {
              document.getElementById("mySidenav").style.width = "0";
            }
        </script>
        <script type="text/javascript">
             //Enable check and uncheck all functionality
            $(".checkbox-toggle").click(function () {
              var clicks = $(this).data('clicks');
              if (clicks) {
                //Uncheck all checkboxes
                $(".mail-checkbox").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
              } else {
                //Check all checkboxes
                $(".mail-checkbox").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
              }
              $(this).data("clicks", !clicks);
            });
        </script>
       
<script type="text/javascript">
	$('#addReportForm').on("submit", function(event){  
           event.preventDefault();  
           if($('#patient_rec_name').val() == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select patient name');
           } 
           else if($('#clinic_ward').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Ward name'); 
           }
           else if($('#clinical_diagnosis').val() == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Clinical Diagnosis'); 
           }
           else  
           {  
                $.ajax({  
                     url:"app/add_report.php",  
                     method:"POST",  
                     data:$('#addReportForm').serialize(),  
                     beforeSend:function(){  
                          $('#btnAddReport').val("Saving report...");  
                     },  
                     success:function(data){ 
                     	  alertify.set('notifier','position', 'top-right');
                 		  alertify.success('Recorded successfully'); 
                          $('#addReportForm')[0].reset();
                          $('#btnAddReport').val("Save");  
                          //$('#ApplyLoanModal').modal('hide');  
                          //$('#member_table').html(data);  
                     }  
                });  
           }  
      });
</script>

<script type="text/javascript">
//adding single patient report
	$('#addTakeReportForm').on("submit", function(event){  
           event.preventDefault();  
           var patient_name = $('#patient_name').val();
           var antibiotic_name = $('#antibiotic_name').val();
           var test_result = $('#test_result').val();

           if(patient_name == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select patient name');
           } 
           else if(antibiotic_name == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Select Antibiotic'); 
           }
           else if(test_result == '')
           {  
                alertify.set('notifier','position', 'top-right');
                 alertify.error('Enter result'); 
           }
           else  
           {  
                
                $.ajax({  
                     url:"app/add_take_report.php",  
                     method:"POST",    
                     data:{
                        'adding_report':true,
                        'patient_name':patient_name,
                         'antibiotic_name':antibiotic_name,
                         'test_result':test_result,
                     },  
                     beforeSend:function(){  
                          $('#btnAddTakeReport').val("Saving report...");  
                     },  
                     success:function(data){ 
                     	  alertify.set('notifier','position', 'top-right');
                 		  alertify.success('Recorded successfully'); 
                         // $('#btnAddTakeReport')[0].reset();
                          $('#btnAddTakeReport').val("Saved");  
                          //$('#ApplyLoanModal').modal('hide');  
                          //$('#member_table').html(data);  
                     }  
                });  
           }  
      });

    //Adding sensitivity report to database
    var spinner = $('#loader');
    $('#SensitivityReportForm').on("submit", function(event){  
           event.preventDefault(); 
           var pn = $('#pn').val();
           var request_type = $('#request_type').val();
           var appearace_microscopy = $('#appearace_microscopy').val();
           var ms_report = $('#ms_report').val();
           var culture_yield = $('#culture_yield').val();
           var date_recieved = $('#date_recieved').val();
           var date_issued = $('#date_issued').val();

           if(request_type == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select request type');
           } 
           else  
           {     
                $.ajax({  
                     url:"app/sensitivity-reports/add_report.php",  
                     method:"POST",    
                     data:{
                        'sensitive_report':true,
                        'pn':pn,
                        'request_type':request_type,
                         'appearace_microscopy':appearace_microscopy,
                         'ms_report':ms_report,
                         'culture_yield':culture_yield,
                         'date_recieved':date_recieved,
                         'date_issued':date_issued,
                     },   
                     success:function(data){
                          spinner.hide(); 
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Report captured successfully'); 
                          $('#SensitivityReportForm')[0].reset();
                          $('#btnSaveResult').val("Saved");  
                     }  
                });
           
           }  
      });

    //Adding new serology report
    $('#SerologyReportForm').on("submit", function(event){  
           event.preventDefault();  
           var pn = $('#pn').val();
           var investigation = $('#investigation').val();
           var invResult = $('#invResult').val();

           if(patient_name == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select patient');
           } 
           else  
           {  
                $.ajax({  
                     url:"app/serology-reports/add_report.php",  
                     method:"POST",    
                     data:{
                        'serology_report':true,
                        'pn':pn,
                        'investigation':investigation,
                        'invResult':invResult,
                     },  
                     beforeSend:function(){  
                          $('#btnSaveResult').val("Saving report...");  
                     },  
                     success:function(data){ 
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Report captured successfully'); 
                          $('#SerologyReportForm')[0].reset();
                          //$('#btnSaveResult').val("Saved");  
                     }  
                });  
           }  
      });

    //sending semen analysis report
    $('#SemenReportForm').on("submit", function(event){  
           event.preventDefault();  
           var pn = $('#pn').val();
           var date_produce = $('#date_produce').val();
           var time_produce = $('#time_produce').val();
           var time_recieve = $('#time_recieve').val();
           var time_examined = $('#time_examined').val();
           var volume = $('#volume').val();
           var appearance = $('#appearance').val();
           var consistency = $('#consistency').val();
           var liquifaction = $('#liquifaction').val();
           var ph = $('#ph').val();
           var concentration = $('#concentration').val();
           var msc = $('#msc').val();
           var fsc = $('#fsc').val();
           var smi = $('#smi').val();
           if(patient_name == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select patient');
           } 
           else  
           {  
                $.ajax({  
                     url:"app/semen-reports/add_report.php",  
                     method:"POST",    
                     data:{
                        'semen_report':true,
                        'pn':pn,
                        'date_produce':date_produce,
                        'time_produce':time_produce,
                        'time_recieve':time_recieve,
                        'time_examined':time_examined,
                        'volume':volume,
                        'appearance':appearance,
                        'consistency':consistency,
                        'liquifaction':liquifaction,
                        'ph':ph,
                        'concentration':concentration,
                        'msc':msc,
                        'fsc':fsc,
                        'smi':smi,
                     },  
                     beforeSend:function(){  
                          $('#btnSaveResult').val("Saving report...");  
                     },  
                     success:function(data){ 
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Report captured successfully'); 
                          $('#SemenReportForm')[0].reset();
                          //$('#btnSaveResult').val("Saved");  
                     }  
                });  
           }  
      });

    //Adding parasitology report
    $('#ParasitologyReportForm').on("submit", function(event){  
           event.preventDefault();  
           var np = $("#np").val();
           var date_sample_collect = $('#date_sample_collect').val();
           var time_sample_collect = $('#time_sample_collect').val();
           var receipt_no = $('#receipt_no').val();
           var clinical_diagnosis = $('#clinical_diagnosis').val();
           var lab_comment = $('#lab_comment').val();
           var spacemen = $('#spacemen').val();
           var investigation = $(".investigation option:selected").val();
           
           if(investigation == "")  
           {  
               
                 alertify.set('notifier','position', 'top-right');
                 alertify.error('Please select investigation');
           } 
           else  
           {  
                $.ajax({  
                     url:"app/parasit-reports/add_report.php",  
                     method:"POST",    
                     data:{
                        'parasit_report':true,
                        'np':np,
                        'date_sample_collect':date_sample_collect,
                        'time_sample_collect':time_sample_collect,
                        'receipt_no':receipt_no,
                        'clinical_diagnosis':clinical_diagnosis,
                        'lab_comment':lab_comment,
                        'spacemen':spacemen,
                        'investigation':investigation,
                     },  
                     beforeSend:function(){  
                          $('#btnSaveResult').val("Saving report...");  
                     },  
                     success:function(data){ 
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Report captured successfully'); 
                         // $('#btnAddTakeReport')[0].reset();
                          //$('#btnSaveResult').val("Saved");  
                     }  
                });  
           }  
      });


    //viewing and posting parsitology patient report
    $(document).on("click",".pReport", function(){
          var pt_id = $(this).attr("id");
          $.ajax({
            url: 'app/code.php',
            type: 'POST',
            data: {pt_id:pt_id},
            dataType:'json',
            success: function (response){
              $('#np').val(response.id);
              $('#TakeParasitologyReportModal').modal('show');

            }

          });
        });

    //viewing and posting semen patient report
    $(document).on("click",".semenReport", function(){
          var pt_id = $(this).attr("id");
          $.ajax({
            url: 'app/code.php',
            type: 'POST',
            data: {pt_id:pt_id},
            dataType:'json',
            success: function (response){
              $('#pn').val(response.id);
              $('#TakeSemenAnalysisReportModal').modal('show');

            }

          });
        });

    //viewing and posting serology patient report
    $(document).on("click",".seroReport", function(){
          var pt_id = $(this).attr("id");
          $.ajax({
            url: 'app/code.php',
            type: 'POST',
            data: {pt_id:pt_id},
            dataType:'json',
            success: function (response){
              $('#pn').val(response.id);
              $('#TakeSerologyReportModal').modal('show');

            }

          });
        });

    //viewing and posting sensitivity patient report
    $(document).on("click",".sensitiveReport", function(){
          var pt_id = $(this).attr("id");
          $.ajax({
            url: 'app/code.php',
            type: 'POST',
            data: {pt_id:pt_id},
            dataType:'json',
            success: function (response){
              $('#pn').val(response.id);
              $('#patient_name').val(response.id);
              $('#TakeSensitivityReportModal').modal('show');

            }

          });
        });


    //viewing list of parasitology report
     function getReportList(id){
          var pt_id = $('#'+id).val();
          $.ajax({
            url: 'app/code.php',
            type: 'POST',
            data: {pt_id:pt_id},
            dataType:'json',
            success: function (response){
              loadParasitologyReportList(id);
              $('#ParasitologyPatientReportModal').modal('show');
            }
          });
        }

    //viewing list of semen report
     function getSemenReportList(id){
          var sem_id = $('#'+id).val();
          $.ajax({
            url: 'app/semen-reports/sem_code.php',
            type: 'POST',
            data: {sem_id:sem_id},
            dataType:'json',
            success: function (response){
              loadSemenReportList(id);
              $('#SemenPatientReportModal').modal('show');
            }
          });
        }

    //viewing list of serology report
     function getSeroReportList(id){
          var ser_id = $('#'+id).val();
          $.ajax({
            url: 'app/serology-reports/ser_code.php',
            type: 'POST',
            data: {ser_id:ser_id},
            dataType:'json',
            success: function (response){
              loadSerologyReportList(id);
              $('#SerologyPatientReportModal').modal('show');
            }
          });
        }

    //viewing list of sensitivity report
     function getSensReportList(id){
          var pt_id = $('#'+id).val();
          $.ajax({
            url: 'app/code.php',
            type: 'POST',
            data: {pt_id:pt_id},
            dataType:'json',
            success: function (response){
              loadSensitivityReportList(id);
              $('#SensitivityPatientReportModal').modal('show');
            }
          });
        }

  //getting patient report
  $(document).on('click', '.TakeSensitivityReport', function(){  
           var member_id = $(this).attr("id");  
           $.ajax({  
                url:"app/sensitivity-report.php",  
                method:"POST",  
                data:{patient_id:patient_id},  
                dataType:"json",  
                success:function(data){      
                     $('#member_name').val(data.member_id);  
                     $('#loan_interest_amt').html(data.exp_interest);   
                     $('#member_id').html(data.id);  
                     $('#btnPayLoan').val("Pay Loan");  
                     $('#pay-loan-modal').modal('show');  
                }  
           });  
      });
  //remove report from list of antibiotics
  $(document).on('click', '.delete_report', function(){  
           var patient_id = $(this).attr("id");  
           if(patient_id != '')  
           {  
                $.ajax({  
                     url:"app/delete_patientreport.php",  
                     method:"POST",  
                     data:{patient_id:patient_id},  
                     success:function(data){  
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Report deleted'); 
                     }  
                });  
           }            
      });
    //deleting report from list of spacement and investigatin in parasitology
      $(document).on('click', '.rmp_report', function(){  
           var prid = $(this).attr("id");  
           if(prid != '')  
           {  
                $.ajax({  
                     url:"app/delete_parasitologyreport.php",  
                     method:"POST",  
                     data:{prid:prid},  
                     success:function(data){  
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Report deleted'); 
                     }  
                });  
           }            
      });

      //deleting report from serology form list
      $(document).on('click', '.seromp_report', function(){  
           var prid = $(this).attr("id");  
           if(prid != '')  
           {  
                $.ajax({  
                     url:"app/delete_serologyreport.php",  
                     method:"POST",  
                     data:{prid:prid},  
                     success:function(data){  
                          alertify.set('notifier','position', 'top-right');
                          alertify.success('Report deleted'); 
                     }  
                });  
           }            
      });  
</script>
</script>
<script>
//this function is usded in getting list of patients for sensitivity result test
$(document).ready(function(){
    loadSensitivityPatientsList();
    function loadSensitivityPatientsList(query)
    {
        $.ajax({
            url:"app/SensitivityReportList.php",
            method:"post",
            data:{query:query},
            success:function(data)
            {
                $('#tbl_SensitivityReportList').html(data);
            }
        });
    }
    
    $('#search_patient').keyup(function(){
        var search = $(this).val();
        if(search != '')
        {
            loadSensitivityPatientsList(search);
        }
        else
        {
            loadSensitivityPatientsList();            
        }
    });
});

    //this function is used for getting list of patienst for serology test result
    $(document).ready(function(){
    loadSerologyList();
    function loadSerologyList(query)
    {
        $.ajax({
            url:"app/SerologyReportList.php",
            method:"post",
            data:{query:query},
            success:function(data)
            {
                $('#tbl_SerologyReportList').html(data);
            }
        });
    }
    
    $('#search_seropatient').keyup(function(){
        var search = $(this).val();
        if(search != '')
        {
            loadSerologyList(search);
        }
        else
        {
            loadSerologyList();            
        }
    });
});
    
//this function is used for getting list of patients for semen analysis test result
 $(document).ready(function(){
    loadSemenAnalysisList();
    function loadSemenAnalysisList(query)
    {
        $.ajax({
            url:"app/SemenAnalysisReportList.php",
            method:"post",
            data:{query:query},
            success:function(data)
            {
                $('#tbl_SemenAnalysisList').html(data);
            }
        });
    }
    
    $('#search_semenpatient').keyup(function(){
        var search = $(this).val();
        if(search != '')
        {
            loadSemenAnalysisList(search);
        }
        else
        {
            loadSemenAnalysisList();            
        }
    });
});

    //this function is used for getting list of patients for parasitology test result
     $(document).ready(function(){
    loadParasitologyList();
    function loadParasitologyList(query)
    {
        $.ajax({
            url:"app/ParasitologyReportList.php",
            method:"post",
            data:{query:query},
            success:function(data)
            {
                $('#tbl_ParasitolotyList').html(data);
            }
        });
    }
    
    $('#search_parapatient').keyup(function(){
        var search = $(this).val();
        if(search != '')
        {
            loadParasitologyList(search);
        }
        else
        {
            loadParasitologyList();            
        }
    });
});
    
</script>

<script>
    //this function is mapping list of serology on the table
     function getSerolList() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
        //var pntid = document.getElementById("patient_name").value;
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("serologyReportList").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "modals/serology/getpatient_report.php", true);
        xhttp.send();
      },2000);
    }
    getSerolList();
    //this function gets list of spacemen and investigation for parasitology
     function getSIList() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
        //var pntid = document.getElementById("patient_name").value;
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("precords").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "modals/parasitology/getpatient_report.php", true);
        xhttp.send();
      },2000);
    }
    getSIList();
  //this function is usded in getting list of patient report for antibiotics
   function loadPatientList() {
    setInterval(function(){
        var xhttp = new XMLHttpRequest();
        var pntid = document.getElementById("patient_name").value;
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
           document.getElementById("records").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "modals/antibiotics/getpatient_report.php?q="+pntid, true);
        xhttp.send();
      },2000);
    }
    loadPatientList();
$(document).ready(function(){  
	// code to get all records from table via select box
   
	$("#patient_name").change(function() {  
    // var id = $(this).find(":selected").val();
		// var dataString = 'ptnid='+ id;    
    loadPatientList();
 	}) 
});
</script>
<script>
//this script is used to retain the active state of report tabs
$(document).ready(function(){
    $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
        localStorage.setItem('activeTab', $(e.target).attr('href'));
    });
    var activeTab = localStorage.getItem('activeTab');
    if(activeTab){
        $('#myTab a[href="' + activeTab + '"]').tab('show');
    }
});
</script>

<script type="text/javascript">
   //this function is usded in getting list of patient report for parasitology
   function loadParasitologyReportList(id) {
        var xhttp = new XMLHttpRequest();
        var pid = $("#"+id).val();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

           document.getElementById("displayParasitologyReportList").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "app/parasit-reports/getReportList.php?pid="+pid, true);
        xhttp.send();
    }

    //this function is usded in getting list of patient report for semen
   function loadSemenReportList(id){
        var xhttp = new XMLHttpRequest();
        var sem_id = $("#"+id).val();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

           document.getElementById("displaySemenReportList").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "app/semen-reports/getReportList.php?sem_id="+sem_id, true);
        xhttp.send();
    }

    //this function is usded in getting list of patient report for serology
   function loadSerologyReportList(id) {
        var xhttp = new XMLHttpRequest();
        var ser_id = $("#"+id).val();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

           document.getElementById("displaySerologyReportList").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "app/serology-reports/getReportList.php?ser_id="+ser_id, true);
        xhttp.send();
    }

    //this function is usded in getting list of patient report for sensitivity
   function loadSensitivityReportList(id) {
        var xhttp = new XMLHttpRequest();
        var pid = $("#"+id).val();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

           document.getElementById("displaySensitivityReportList").innerHTML = this.responseText;
          }
        };
        xhttp.open("POST", "app/sensitivity-reports/getReportList.php?pid="+pid, true);
        xhttp.send();
    }
</script>
<!-- Editing patient report scripts for sensitivity report -->
<script>
    //update patient sensitivity record changes to database
        $('#btnSaveSensPatientResult').click(function(e){
            e.preventDefault();
            var patient_id = $('#id_edit').val();
            var request_type = $('.request_type').val();
            var appearace_microscopy = $('.appearace_microscopy').val();
            var ms_report = $('.ms_report').val();
            var culture_yield = $('.culture_yield').val();
            var date_recieved = $('.date_recieved').val();
            var date_issued = $('.date_issued').val();
            $.ajax({
                url:'app/sensitivity-reports/UpdateChanges.php',
                type:'POST',
                data:{
                    'checking_update':true,
                    'patient_id':patient_id,
                    'request_type':request_type,
                    'appearace_microscopy':appearace_microscopy,
                    'ms_report':ms_report,
                    'culture_yield':culture_yield,
                    'date_recieved':date_recieved,
                    'date_issued':date_issued
                },
                success: function(response){
                    $('#EditSensitivityReportModal').modal('hide');
                    $('.message-show').append('\<div class="alert alert-success alert-dismissible fade show" role="alert">\
                  <strong>Hey!</strong> '+response+'\
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\
                  </div>\
                  ');
                   
                }
            });

        });
    //fetch patient sensitivity record into a form for editing
          $(document).on("click",".sensEdit_btn", function(){
            var patient_id = $(this).closest('tr').find('.patient_id').text();
            $.ajax({
                url:'app/sensitivity-reports/updateSensPatient.php',
                type:'POST',
                data:{
                    'checking_edit':true,
                    'patient_id':patient_id
                },
                success: function(response){
                    $.each(response, function(key, patientedit) {
                        $('#id_edit').val(patientedit['id']);
                        $('.request_type').val(patientedit['request_type']);
                        $('.appearace_microscopy').val(patientedit['app_microscopy']);
                        $('.ms_report').val(patientedit['micro_serology']);
                        $('.culture_yield').val(patientedit['culture_yeilded']);
                        $('.date_recieved').val(patientedit['date_recieved']);
                        $('.date_issued').val(patientedit['date_issued']);
                    });

                    $('#EditSensitivityReportModal').modal('show');
                }
            });
        });
</script>

<!-- Editing patient report scripts for serology report -->
<script>
    //update patient sensitivity record changes to database
        $('#btnSaveSeroPatientResult').click(function(e){
            e.preventDefault();
            var patient_id = $('#seroid_edit').val();
            var investigation = $('.investigation').val();
            var invResult = $('.invResult').val();
            $.ajax({
                url:'app/serology-reports/UpdateChanges.php',
                type:'POST',
                data:{
                    'checking_update':true,
                    'patient_id':patient_id,
                    'investigation':investigation,
                    'invResult':invResult,
                },
                success: function(response){
                    $('#EditSerologyReportModal').modal('hide');
                    $('.message-show').append('\<div class="alert alert-success alert-dismissible fade show" role="alert">\
                  <strong>Hey!</strong> '+response+'\
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\
                  </div>\
                  ');
                   
                }
            });

        });
    //fetch patient serology record into a form for editing
          $(document).on("click",".seroEdit_btn", function(){
            var patient_id = $(this).closest('tr').find('.patient_id').text();
            $.ajax({
                url:'app/serology-reports/updateSeroPatient.php',
                type:'POST',
                data:{
                    'checking_edit':true,
                    'patient_id':patient_id
                },
                success: function(response){
                    $.each(response, function(key, seropatientedit) {
                        $('#seroid_edit').val(seropatientedit['id']);
                        $('.investigation').val(seropatientedit['investigation']);
                        $('.invResult').val(seropatientedit['result']);
                       
                    });

                    $('#EditSerologyReportModal').modal('show');
                }
            });
        });
</script>

<!-- Editing patient report scripts for semen report -->
<script>
    //update patient semen record changes to database
        $('#btnSaveSemenPatientResult').click(function(e){
            e.preventDefault();
            var patient_id = $('#semenid_edit').val();
            var date_produce = $('.date_produce').val();
            var time_produce = $('.time_produce').val();
            var time_recieve = $('.time_recieve').val();
            var time_examined = $('.time_examined').val();
            var volume = $('.volume').val();
            var appearance = $('.appearance').val();
            var consistency = $('.consistency').val();
            var liquifaction = $('.liquifaction').val();
            var ph = $('.ph').val();
            var concentration = $('.concentration').val();
            var msc = $('.msc').val();
            var fsc = $('.fsc').val();
            var smi = $('.smi').val();
            $.ajax({
                url:'app/semen-reports/UpdateChanges.php',
                type:'POST',
                data:{
                    'checking_update':true,
                    'patient_id':patient_id,
                    'date_produce':date_produce,
                    'time_produce':time_produce,
                    'time_recieve':time_recieve,
                    'time_examined':time_examined,
                    'volume':volume,
                    'appearance':appearance,
                    'consistency':consistency,
                    'liquifaction':liquifaction,
                    'ph':ph,
                    'concentration':concentration,
                    'msc':msc,
                    'fsc':fsc,
                    'smi':smi
                },
                success: function(response){
                    $('#EditSemenAnalysisReportModal').modal('hide');
                    $('.message-show').append('\<div class="alert alert-success alert-dismissible fade show" role="alert">\
                  <strong>Hey!</strong> '+response+'\
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\
                  </div>\
                  ');
                   
                }
            });

        });
    //fetch patient semen record into a form for editing
          $(document).on("click",".semenEdit_btn", function(){
            var patient_id = $(this).closest('tr').find('.patient_id').text();
            $.ajax({
                url:'app/semen-reports/updateSemenPatient.php',
                type:'POST',
                data:{
                    'checking_edit':true,
                    'patient_id':patient_id
                },
                success: function(response){
                    $.each(response, function(key, semenpatientedit) {
                        $('#semenid_edit').val(semenpatientedit['id']);
                        $('.date_produce').val(semenpatientedit['date_produce']);
                        $('.time_produce').val(semenpatientedit['time_produce']);
                        $('.time_recieve').val(semenpatientedit['time_recieve']);
                        $('.time_examined').val(semenpatientedit['time_examine']);
                        $('.volume').val(semenpatientedit['semen_volume']);
                        $('.appearance').val(semenpatientedit['appearance']);
                        $('.consistency').val(semenpatientedit['consistency']);
                        $('.liquifaction').val(semenpatientedit['liquifaction']);
                        $('.ph').val(semenpatientedit['ph']);
                        $('.concentration').val(semenpatientedit['concentration']);
                        $('.msc').val(semenpatientedit['msc']);
                        $('.fsc').val(semenpatientedit['fsc']);
                        $('.smi').val(semenpatientedit['smi']);
                       
                    });

                    $('#EditSemenAnalysisReportModal').modal('show');
                }
            });
        });
</script>

<!--for parasitology this is the script
 Editing patient report scripts for parasitology report -->
<script>
    //update patient parasitology record changes to database
        $('#btnSaveParasitPatientResult').click(function(e){
            e.preventDefault();
            var patient_id = $('#parasitid_edit').val();
            var investigation = $('.investigation').val();
            var date_sample_collect = $('.date_sample_collect').val();
            var time_sample_collect = $('.time_sample_collect').val();
            var receipt_no = $('.receipt_no').val();
            var clinical_diagnosis = $('.clinical_diagnosis').val();
            var lab_comment = $('.lab_comment').val();
            var spacemen = $('.spacemen').val();
            $.ajax({
                url:'app/parasit-reports/UpdateChanges.php',
                type:'POST',
                data:{
                    'checking_update':true,
                    'patient_id':patient_id,
                    'investigation':investigation,
                    'date_sample_collect':date_sample_collect,
                    'time_sample_collect':time_sample_collect,
                    'receipt_no':receipt_no,
                    'clinical_diagnosis':clinical_diagnosis,
                    'lab_comment':lab_comment,
                    'spacemen':spacemen
                },
                success: function(response){
                    $('#EditParasitologyReportModal').modal('hide');
                    $('.message-show').append('\<div class="alert alert-success alert-dismissible fade show" role="alert">\
                  <strong>Hey!</strong> '+response+'\
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\
                  </div>\
                  ');
                   
                }
            });

        });
    //fetch patient parasitology record into a form for editing
          $(document).on("click",".parasitEdit_btn", function(){
            var patient_id = $(this).closest('tr').find('.patient_id').text();
            $.ajax({
                url:'app/parasit-reports/updateParasitPatient.php',
                type:'POST',
                data:{
                    'checking_edit':true,
                    'patient_id':patient_id
                },
                success: function(response){
                    $.each(response, function(key, parasitpatientedit) {
                        $('#parasitid_edit').val(parasitpatientedit['id']);
                        $('.investigation').val(parasitpatientedit['investigation']);
                        $('.date_sample_collect').val(parasitpatientedit['date_sample_collection']);
                        $('.time_sample_collect').val(parasitpatientedit['time_sample_collection']);
                        $('.receipt_no').val(parasitpatientedit['reciept_no']);
                        $('.clinical_diagnosis').val(parasitpatientedit['clinical_diagnosis']);
                        $('.lab_comment').val(parasitpatientedit['comment']);
                        $('.spacemen').val(parasitpatientedit['spacemen']);
                        
                    });

                    $('#EditParasitologyReportModal').modal('show');
                }
            });
        });
</script>
</body>
</html>