 <!-- Check all button -->
<!-- <button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i>
</button> -->
<form name="mailsForm" id="mailsForm" method="post">
All <input type="checkbox" class="btn btn-default btn-sm checkbox-toggle" id="selectall" name="checkall" value="Active">
<div class="btn-group">
  <button type="button" name="delete" class="btn btn-default btn-sm" onClick="setDeleteMail();"><i class="fa fa-trash-o"></i></button>
  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-reply"></i></button>
  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-share"></i></button>
</div> 
 <a href="HomePage.php" class="btn btn-default btn-sm"><i class="fa fa-refresh"></i></a>
