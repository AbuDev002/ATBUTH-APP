<?php
        //session_start();
    ob_start();
    //error_reporting(1);
    require_once 'vendor/autoload.php';
    if(isset($_GET['pid'])){
      $pid = (int) $_GET['pid'];
    }
    
?>
<?php include_once('connection.php');?>

<!Doctype html>
<html>
  <head>
    <title>Patient Report Form</title>

    <style type="text/css">
      #container{
        width:100%;
        height:auto;
        margin:0px auto;
        margin-top:20px;
        text-indent:5px;
        font-size:12px;
                               
      }
        
      th#mdb{
        background-image:url("images/sch-logo.png") no-repeat;
        background-size:contain;
      }
      
      #report_details td{
        border:1px solid black;
        border-collapse:collapse;
      }
      
      .head{
        background:#91C5D4;
        }
    @page { 
        margin-top: 180px;
        margin-left: 50px;
        margin-right: 50px;
        /*margin-bottom: 50px;*/
        background-color: skyblue;
       }
      #header { position: fixed; left: -45px; top: -180px; right: -45px; height: 100px; background-color: #f5f5f5; text-align: center; width:100%; }
      #footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 160px; background-color: #f5f5f5; }
      /*#footer .page:after { content: counter(page, upper-roman); }*/
      
      /*table#report_details{page-break-inside:avoid}*/
      .paragraph{
        text-align: justify;
        line-height: 30px;
      }

      .left_area{
        width:30%;
        /* height:500px; */
        float:left;
        display:block;
        min-height: 550px;
       font-size: 14px;
        /*border:1px solid black;*/
      }
      .right_area{
        width:70%;
        /* min-height:500px; */
        /*border-left:1px solid black;*/
        border-radius:10px;
        float:right;
        display:block;
       /* border:3px solid black;*/
        min-height: 550px;
      }
      .right_area ul{
        list-style-type: none;
        margin:0px;
        padding:0px;
      }
      .right_area ul li{
        line-height: 26px;
      }
      .clear{
        clear:both;
        overflow: auto;
      }

      .fleft{
        float: left;
        border: 1px solid black;
        height: 50px;
        width: 50%;
        margin-top: 5px;
      }
      .fright{
        float: right;
        border: 1px solid black;
        height: 60px;
        width: 49%;
       /* margin-top: 5px;*/
      }
      .clear{
        clear: both;
      }

      .uright{
        width:50%;
        float:right;
        font-size: 14px;
      }
      .uleft{
              width:50%;
              float:left;
              font-size: 14px;
            }
      .hright{
        width:50%;
        /*border:1px solid black;*/
        float:right;
        font-size: 14px;
        margin-top:-80px;
      }

      .hright ul{
        list-style-type: none;
        padding:0px;
        margin:0px;
      }

       .hright ul li{
       line-height: 26px;
      }

      .hleft{
            width:50%;
            /*border:1px solid black;*/
            float:left;
            font-size: 14px;
            margin-top:-80px;
          }
        .hleft ul{
        list-style-type: none;
        padding:0px;
        margin:0px;
      }

      .hleft ul li{
        line-height: 26px;
      }
      /*.tbl_antibiotics{
        width:100%;
        border:1px solid black;
        border-spacing: -1px;
        /*margin-top:20px;
      }*/
      .tbl_antibiotics td{
        border:1px solid black;
        
      }

      

      ul.reportList{
        list-style-type: none;
        padding:0px;
        margin:0px;
      }
      ul.reportList li{
        line-height: 26px;
      }

      .box-tick{
        height: 15px;
        width:40px;
        border:1px solid black;
        margin:3px;
        margin-bottom: 0px;
        float-left;
      }
      .lab_result{
        height: 170px;
        border:1px solid black;
        width: 100%;
      }
    </style>
  </head>
  
<body>
<div id="container">

<div id="header">
    <table align="center"  cellpadding="0"  width="100%" style="font-size:12px; border-collapse:collapse;">
      <tr>
        <td align="right" width="50"><img src="http://localhost/atbuthapp/images/abuthlogo.png" width="100" height="80" style="margin-top: 10px;"></td>
        <td align="center" colspan="2"><h1>ABUBAKAR TAFAWA BALEWA UNIVERSITY <br/> TEACHING HOSPITAL, BAUCHI</h1></td>
      </tr>
      <tr>
        
        <td colspan="3" align="center" valign="top" height="10"><h2 style="padding:0px; background:#29166F; color:#fff;">PARASITOLOGY LABORATORY REQUEST/REPORT FORM</h2></td>
        
      </tr>
      
    </table>
    
</div>
  <div id="footer">
    <strong>N.B: <i>Improper completionof Lab Form and collection of speciment may lead to rejection of sample(s)</i></strong>
  </div>

  <?php
    include_once('connection.php');
    $patientname_sql = mysqli_query($conms,"select * from patients where id=$pid");
    $patient_data = mysqli_fetch_array($patientname_sql);
  ?>

<div class="hleft">
  <h3 style="text-decoration: underline;">PATIENT'S DATA</h3>
    <ul>
      <li><strong>Name:</strong> <?php echo strtoupper($patient_data['surname'].' '.$patient_data['firstname'].' '.$patient_data['othername']);?></li>
      <li><strong>Age:</strong><?php echo strtoupper($patient_data['age']);?></li>
      <li><strong>Sex:</strong> <?php echo strtoupper($patient_data['gender']);?></li>
      <li><strong>Address:</strong><?php echo strtoupper($patient_data['address']);?></li>
      <li><strong>Wards/Clinic:</strong><?php echo strtoupper($patient_data['ward_clinic']);?></li>
      <li><strong>Hospital No:</strong> <?php echo strtoupper($patient_data['hospital_no']);?></li>
    </ul>
</div>
<div class="hright">
   <h3 style="text-decoration: underline;">CLINICAL DETAILS</h3>
  <ul>
      <li><strong>Clinical Diagnosis:</strong>..................................................................</li>
      <li>...................................................................................................</li>
      <li><strong>Clinician/Consultant:</strong> <?php echo strtoupper($patient_data['consultant']);?></li>
      <li><strong>Signature:</strong>...................................................................................</li>
      <li><strong>Date:</strong>...........................................................................................</li>
    </ul>
</div>
<div class="clear"></div>
<br>
<br>
<br>
<div style="border-top:1px solid black;text-align: center;"><h3 style="padding:0px;margin:0px;text-decoration: underline;font-size: 16px;">LAB USE ONLY</h3></div>

<!-- <P style="font-size:12px;text-align:right"> 2347</P> -->
<div class="container">
      <div class="left_area">
       
      </div>

      <!-- begin right area -->
      <div class="right_area">
        <ul>
          <li>LAB. NO............................................................................</li>
          <li>Date of Sample Collection..................................................</li>
          <li>Time of Sample Collection..................................................</li>
          <li>Receipt Number...................................................................</li>
        </ul>
      </div>
      <div class="clear"></div> 
      <!-- <h4>Comments______________________________________________________________________________________________________</h4> -->
       <p>________________________________________________________________________________________________________________</p>
        <p>________________________________________________________________________________________________________________</p>

    <div style="text-align: center;"><h3 style="padding:0px;margin:0px;text-decoration: underline;font-size: 16px;">SPACIMEN(S) REQUESTED</h3></div>    
    <table style="width:100%;border-top:1px solid black;border-bottom: 1px solid black;margin-top:10px;">
      <tr>
        <td width="259"><strong>Spacemen(s)</strong></td>
        <td><strong>Investigation(s)</strong></td>
      </tr>
    </table>
        <div class="uleft">
          <table class="request_type">
                <tr>
                  <td width="50"><div class="box-tick"></div></td>
                  <td>Blood</td>
                </tr>
                <tr>
                  <td><div class="box-tick"></div></td>
                  <td>Stool</td>
                </tr>
                <tr>
                  <td><div class="box-tick"></div></td>
                  <td>Urine</td>
                </tr>
                  <td><div class="box-tick"></div></td>
                  <td>CSF</td>
                <tr>
                  <td><div class="box-tick"></div></td>
                  <td>Skin/Tissue</td>
                </tr>
                <tr>
                  <td><div class="box-tick"></div></td>
                  <td>Sputum</td>
                </tr>
                <tr>
                  <td><div class="box-tick"></div></td>
                  <td>Aspirate</td>
                </tr>
                <tr>
                  <td><div class="box-tick"></div></td>
                  <td>Others..................................................</td>
                </tr>
        </table>
        </div>
        <div class="uright">
          <table class="request_type">
                  <tr>
                    <td width="50"><div class="box-tick"></div></td>
                    <td>Microscopy</td>
                  </tr>
                  <tr>
                    <td><div class="box-tick"></div></td>
                    <td>Malaria Parasite</td>
                  </tr>
                  <tr>
                    <td><div class="box-tick"></div></td>
                    <td>Microfilaria (specify)</td>
                  </tr>
                  <tr>
                    <td><div class="box-tick"></div></td>
                    <td>Others (specify).............................................</td>
                  </tr>
          </table>
        </div>
        <div class="clear"></div>
        <div class="lab_result">
          <div style="text-align: center;"><h3 style="padding:0px;margin:0px;text-decoration: underline;font-size: 16px;">LABORATORY RESULT(S)</h3>
              
          </div>    
        </div>
        <!-- <div style="text-align: center;">
          <P><strong>Name:......................................................Signature:...............................................................Date:............................................................................</strong></P>
          <i><strong>(Medical Laoboratory Scientist)</strong></i>
        </div> -->
        <div class="fleft">
            <strong><i>NAME/ SIGNATURE OF MEDICAL LAB. SCIENTIST</i></strong>
        </div>
        <div class="fright">
            <strong><i>CONSULTANT COMMENT</i></strong>
        </div>
        <div class="clear"></div>
</div>
</div>

</body>
</html>
<?php   
  $html = ob_get_clean();
  use Dompdf\Dompdf;
  use Dompdf\Options;
  require_once 'vendor/autoload.php';
  $options = new Options();
    $options->set('isRemoteEnabled', TRUE);
    $options->set('debugKeepTemp', TRUE);
    $options->set('isHtml5ParserEnabled', true);
  $dompdf = new DOMPDF($options);
  $contxt = stream_context_create([ 
    'ssl' => [ 
        'verify_peer' => FALSE, 
        'verify_peer_name' => FALSE,
        'allow_self_signed'=> TRUE
    ] 
]);
$dompdf->setHttpContext($contxt);
  $dompdf->set_paper("A4","Portrait");
  $dompdf->loadHtml($html);
  $dompdf->render();
  $dompdf->stream('parasitology_report.pdf');
?>