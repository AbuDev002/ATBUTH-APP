<?php
include_once('connection.php');
if(isset($_POST["supplier_name"],$_POST["product_name"], $_POST["stock_level"], $_POST["price"]))
{
 $supplier_name = mysqli_real_escape_string($conms, $_POST["supplier_name"]);
 $product_name = mysqli_real_escape_string($conms, $_POST["product_name"]);
 $stock_level = mysqli_real_escape_string($conms, $_POST["stock_level"]);
 $price = mysqli_real_escape_string($conms, $_POST["price"]);
 $query = "INSERT INTO products (supplier_name,product_name, stock_level,price) VALUES('$supplier_name','$product_name', '$stock_level', '$price')";
 if(mysqli_query($conms, $query))
 {
  echo 'Data Inserted';
 }
}
?>