<?php
include_once('connection.php');
if(isset($_GET['deleteuser'])) {
$deltid = $_GET['deleteuser']; 
$usertDetails = mysqli_query($conms,"DELETE FROM userinfo WHERE user_id=".$deltid."");
header('location:users.php');
}else{
    header('location:users.php');
}
?>