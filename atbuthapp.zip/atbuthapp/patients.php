<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Users";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<form action="" method="post" enctype="multipart/form-data">
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					 <a href="add_patient.php" class="btn btn-primary margin-bottom"><i class="fa fa-plus"></i> Add New Patient</a>
					 <hr/>
					 <table class="table table-bordered table-responsive table-striped table-hover custom_table">
					 	<thead>
						 	<tr>
						 		<th>S/N</th>
						 		<th>Patient Name</th>
						 		<th>Age</th>
						 		<th>Gender</th>
						 		<th>Address</th>
						 		<th></th>
						 		<th></th>
						 	</tr>
					 	</thead>
					 	<tbody>
					 	<?php 
					 		$count = 0;
					 		
					 			include_once('connection.php');
					 			$getcustomer_sql = mysqli_query($conms,"select * from patients");
					 			while($rows_rs = mysqli_fetch_array($getcustomer_sql)){
					 			$count++;
					 			
							 	?>
							 	<tr>
							 		<td><?php echo $count;?></td>
							 		<td><?php echo $rows_rs['surname'].' '.$rows_rs['firstname'].' '.$rows_rs['othername'];?></td>
							 		<td><?php echo $rows_rs['age'];?></td>
							 		<td><?php echo $rows_rs['gender'];?></td>
									 <td><?php echo $rows_rs['address'];?></td>
									<?php if($_SESSION['account_type'] == 'Superadmin'){?>
							 		<td><a onclick="return confirm('Are you sure to delete');" href="deletepatient.php?deletepatient=<?php echo $rows_rs['id'];?>"><i class="fa fa-trash"></i></a></td>
							 		<td><a href="#"><i class="fa fa-edit"></i></a></td>
									<?php }?>
								</tr>
							<?php } ?>
					 </tbody>
					 </table>
					</div>
						
				</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>