 <?php
include_once('connection.php');
function formatMoney($number, $fractional=false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}
?>
 <div class="container">
   <?php //if($_SESSION['account_type'] =="Superadmin"){?>
      <div class="row">
       
        <div class="col-md-12" style="margin-bottom: 20px;">
        <div class="jumbotron">
          <h1 class="display-4">ABUTH MedMicroLab-App</h1>
          <p class="lead">The application is designed to ease report generating in the Medical Microbiology Laboratory.</p>
          <hr class="my-4">
            <div class="row"> 
                <!-- <div class="col-md-3"> 
                    <a class="btn btn-primary btn-lg" href="#" role="button">New Report</a>
                </div> -->
                <div class="col-md-8" style="text-align:justify;"> 
                     
                    <ul class="how_to">
                      <li><strong>HOW TO USE</strong>
                          <ul>
                             <li><strong>New Report:</strong> This allows you to input patient medical report, Record test and generate result</li>
                      <li><strong>Patients:</strong> This is where you can register and remove patient from record</li>
                      <li><strong>Antibiotics:</strong> This is a place where you can add and remove antibiotics</li>
                      <li><strong>Profile:</strong> This is where you can manage your account profile</li>
                      <li><strong>Change Password:</strong> This allows you to change your account password</li>
                          </ul>
                      </li>

                     
                    </ul>
                </div>
                <div class="col-md-4">
                  
                   <ul class="how_to">
                      <li><strong>OPEATIONAL STEPS</strong>
                          <ul>
                             <li><strong>Step 1:</strong> Register a new patient</li>
                      <li><strong>Step 2:</strong> Click on New Report</li>
                      <li><strong>Step 3:</strong> Enter patient medical record</li>
                      <li><strong>Step 4:</strong> Record Test Result </li>
                      <li><strong>Step 5:</strong> Print Report </li>
                          </ul>
                      </li>

                     
                    </ul>
                </div>
            </div>  
        </div>
        </div>

      
       
        <!--end of dashobard count-->
         
   </div>
   <!-- <h4>Track Patients Report</h4>
   <div class="row">
     <div class="col-md-12">
        <form action="" method="post">
    <table class="table table-bordered">
      <tr>
        <td>From: <input name="from" type="date"  class="form-control tcal" value="<?php //if(isset($_POST['from'])){ echo $_POST['from'];}?>"  autocomplete="off"/></td>
        <td>To: <input name="to" type="date" value="<?php //if(isset($_POST['to'])){ echo $_POST['to'];}?>"  autocomplete="off"  class="form-control tcal" /></td>
      </tr>
      <tr>
        <td colspan="2" align="center"><input name="btnSearch" type="submit" value="Seach"  class="btn btn-primary" /></td>
      </tr>
    </table> -->
  
      
   
  </form><br />
   
    <?php
    // if(isset($_POST['btnSearch'])){
    // $a=$_POST['from'];
    // $b=$_POST['to'];
    // $result1 = mysqli_query($conms,"SELECT * FROM patients_lab_report where report_date BETWEEN '$a' AND '$b'");
    // while($row = mysqli_fetch_array($result1))
    // {
    //   $rrr=$row['total_amt'];
    //   echo "&#8358;".formatMoney($rrr, true);
    //  }
    // }
    
  ?>
     </div>
   </div>
  <?php //} ?>

   <br/>
   <br/>
   <div class="row">
     
                </div>
            </div>
        </div>
       
   </div>

 </div>
 