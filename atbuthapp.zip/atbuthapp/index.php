<?php $title ="Login Page";?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu.php');?>

	<div  class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				
		<center>
		
		<p><img src="images/abuthlogo.png" class="rounded-circle" width="100" height="100"></p>
		<div class="app-name" style="font-weight:bold !important;color:#29166F;"><i class="fas fa-hospital-user"></i> ATBUTH MedMicroLab App.</div>
		</center>

		<div  class="card" id="formContainer">
			<div class="card-body">
	            <p><div id="error"></div></p>
				
				<form  method="post" id="user-login">
					<center><h5 class="card-title"><i class="fa fa-users"></i> User's Login</h5></center>
					<br/>
					<br/>
					<div class="form-group">
						<input type="email" name="email" id="email" placeholder="Email address..." autocomplete="off" class="form-control">
					</div>
					<div class="form-group">
						<input type="password" name="password" id="password" placeholder="Password..." autocomplete="off" class="form-control">
					</div>
					<div class="form-group">
						<small id="emailHelp" class="form-text text-info" style="font-size:12px;text-align:right;"><i class="fa fa-question-circle"></i> <a href="#">Forgot your password? </a></small>
					</div>
					<div class="form-group">
						<button  class="btn btn-primary btn-block login" id="working"><i class="fa fa-sign-in"></i> Login </button>
					</div>	
				</form>
				</div>
		
			</div>

<div class="text-center" style="color:#222; font-size:10px;margin-top:10px;">Copyright &copy;
                                    <?php echo date('Y', time())?>
                                        ATBU Teaching Hospital - All right reserved.
                                            <br>Powered By <a href="https://brownwebappz.codes/" target="_blank" title="Developers" data-toggle="popover" data-trigger="hover" data-content="A product of Brown WebAppz" data-placement="bottom">Brown WebAppz</a></div>
                 
		</div>
		<div class="col-md-4"></div>
</div>
</div>
<?php include('incs/footer.php');?>