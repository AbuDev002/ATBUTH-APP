$('#toggle_msg').click(function(){
	var value = $('#toggle_msg').attr('value');
	$('#message').toggle('fast');
	
	if(value == 'Hide'){
		$('#toggle_msg').attr('value', 'Show');
	
	}else if(value == 'Show')
		$('#toggle_msg').attr('value', 'Hide');
	
});


$(document).ready(function(){
	
	$('#msg').fadeIn('slow');
	
	$(':submit').click(function(){
		$(this).attr('value','Please wait...');
	});
	
	$(':input').focusin(function(){
		$(this).css('background-color','#f5f5f5');
	});
	
	$(':input').blur(function(){
		$(this).css('background-color','#fff');
	
	});
	
	
	$('#stafflist').change(function(){
		var value = $(this).attr('value');
			if(value !==""){
				$(this).parent().submit();
			}
	
	});
	
		ion.sound({
				sounds: [
					{name: "branch_break"}
				
				],
				path: "sounds/",
				preload: true,
				volume: 1.0
			});

			$(".b01").hover( function(){
				ion.sound.play("branch_break");
			});

	
});