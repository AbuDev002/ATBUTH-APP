//this function is used to delete a student record
function setDeleteMail() {
var checkBoxes = document.getElementsByClassName('mail-checkbox');
 var isChecked = false;
 for (var i = 0; i < checkBoxes.length; i++) {
        if ( checkBoxes[i].checked ) {
            isChecked = true;

        };
    };
if ( isChecked ) {
	if(confirm("Are you sure you want to delete?")) {
		document.mailsForm.action = "delete_mail.php";
		document.mailsForm.submit();
	}
	} else {
		alert( 'Please, select the mail box you want to delete!' );
	}   
}
